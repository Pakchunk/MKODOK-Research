#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function EnemySword_ABP.EnemySword_ABP_C.AnimGraph
struct UEnemySword_ABP_C_AnimGraph_Params
{
	struct FPoseLink                                   AnimGraph;                                                 // (Parm, OutParm, NoDestructor)
};

// Function EnemySword_ABP.EnemySword_ABP_C.BlueprintUpdateAnimation
struct UEnemySword_ABP_C_BlueprintUpdateAnimation_Params
{
	float                                              DeltaTimeX;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function EnemySword_ABP.EnemySword_ABP_C.BlueprintInitializeAnimation
struct UEnemySword_ABP_C_BlueprintInitializeAnimation_Params
{
};

// Function EnemySword_ABP.EnemySword_ABP_C.AnimNotify_AttackEnded
struct UEnemySword_ABP_C_AnimNotify_AttackEnded_Params
{
};

// Function EnemySword_ABP.EnemySword_ABP_C.AnimNotify_AttackNotify
struct UEnemySword_ABP_C_AnimNotify_AttackNotify_Params
{
};

// Function EnemySword_ABP.EnemySword_ABP_C.ExecuteUbergraph_EnemySword_ABP
struct UEnemySword_ABP_C_ExecuteUbergraph_EnemySword_ABP_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
