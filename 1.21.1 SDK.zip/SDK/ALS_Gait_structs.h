#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// UserDefinedEnum ALS_Gait.ALS_Gait
enum class EALS_Gait : uint8_t
{
	ALS_Gait__NewEnumerator0       = 0,
	ALS_Gait__NewEnumerator1       = 1,
	ALS_Gait__NewEnumerator2       = 2,
	ALS_Gait__ALS_MAX              = 3,

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
