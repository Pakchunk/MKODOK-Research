#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function Base_AI_Enemy.Base_AI_Enemy_C.ReceiveBeginPlay
struct ABase_AI_Enemy_C_ReceiveBeginPlay_Params
{
};

// Function Base_AI_Enemy.Base_AI_Enemy_C.ReceiveTick
struct ABase_AI_Enemy_C_ReceiveTick_Params
{
	float                                              DeltaSeconds;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function Base_AI_Enemy.Base_AI_Enemy_C.Attack
struct ABase_AI_Enemy_C_Attack_Params
{
};

// Function Base_AI_Enemy.Base_AI_Enemy_C.AttackEnded
struct ABase_AI_Enemy_C_AttackEnded_Params
{
};

// Function Base_AI_Enemy.Base_AI_Enemy_C.AttackNotify
struct ABase_AI_Enemy_C_AttackNotify_Params
{
};

// Function Base_AI_Enemy.Base_AI_Enemy_C.AttackRefresh
struct ABase_AI_Enemy_C_AttackRefresh_Params
{
};

// Function Base_AI_Enemy.Base_AI_Enemy_C.ReceiveAnyDamage
struct ABase_AI_Enemy_C_ReceiveAnyDamage_Params
{
	float                                              Damage;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UDamageType*                                 DamageType;                                                // (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class AController*                                 InstigatedBy;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class AActor*                                      DamageCauser;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function Base_AI_Enemy.Base_AI_Enemy_C.DEATH
struct ABase_AI_Enemy_C_DEATH_Params
{
};

// Function Base_AI_Enemy.Base_AI_Enemy_C.BndEvt__PawnSensing_K2Node_ComponentBoundEvent_0_SeePawnDelegate__DelegateSignature
struct ABase_AI_Enemy_C_BndEvt__PawnSensing_K2Node_ComponentBoundEvent_0_SeePawnDelegate__DelegateSignature_Params
{
	class APawn*                                       Pawn;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function Base_AI_Enemy.Base_AI_Enemy_C.BndEvt__PawnSensing_K2Node_ComponentBoundEvent_1_HearNoiseDelegate__DelegateSignature
struct ABase_AI_Enemy_C_BndEvt__PawnSensing_K2Node_ComponentBoundEvent_1_HearNoiseDelegate__DelegateSignature_Params
{
	class APawn*                                       Instigator;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                                     Location;                                                  // (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              Volume;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function Base_AI_Enemy.Base_AI_Enemy_C.ExecuteUbergraph_Base_AI_Enemy
struct ABase_AI_Enemy_C_ExecuteUbergraph_Base_AI_Enemy_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function Base_AI_Enemy.Base_AI_Enemy_C.ParentDeathEvent__DelegateSignature
struct ABase_AI_Enemy_C_ParentDeathEvent__DelegateSignature_Params
{
};

// Function Base_AI_Enemy.Base_AI_Enemy_C.ParentAttackEvent__DelegateSignature
struct ABase_AI_Enemy_C_ParentAttackEvent__DelegateSignature_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
