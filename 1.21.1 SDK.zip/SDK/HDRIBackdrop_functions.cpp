// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function HDRIBackdrop.HDRIBackdrop_C.CreateMaterial
// (Public, HasDefaults, BlueprintCallable, BlueprintEvent)
void AHDRIBackdrop_C::CreateMaterial()
{
	static auto fn = UObject::FindObject<UFunction>("Function HDRIBackdrop.HDRIBackdrop_C.CreateMaterial");

	AHDRIBackdrop_C_CreateMaterial_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function HDRIBackdrop.HDRIBackdrop_C.UserConstructionScript
// (Event, Public, BlueprintCallable, BlueprintEvent)
void AHDRIBackdrop_C::UserConstructionScript()
{
	static auto fn = UObject::FindObject<UFunction>("Function HDRIBackdrop.HDRIBackdrop_C.UserConstructionScript");

	AHDRIBackdrop_C_UserConstructionScript_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
