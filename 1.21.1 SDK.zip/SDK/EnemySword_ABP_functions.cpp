// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function EnemySword_ABP.EnemySword_ABP_C.AnimGraph
// (HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FPoseLink               AnimGraph                      (Parm, OutParm, NoDestructor)
void UEnemySword_ABP_C::AnimGraph(struct FPoseLink* AnimGraph)
{
	static auto fn = UObject::FindObject<UFunction>("Function EnemySword_ABP.EnemySword_ABP_C.AnimGraph");

	UEnemySword_ABP_C_AnimGraph_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (AnimGraph != nullptr)
		*AnimGraph = params.AnimGraph;

}


// Function EnemySword_ABP.EnemySword_ABP_C.BlueprintUpdateAnimation
// (Event, Public, BlueprintEvent)
// Parameters:
// float                          DeltaTimeX                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UEnemySword_ABP_C::BlueprintUpdateAnimation(float DeltaTimeX)
{
	static auto fn = UObject::FindObject<UFunction>("Function EnemySword_ABP.EnemySword_ABP_C.BlueprintUpdateAnimation");

	UEnemySword_ABP_C_BlueprintUpdateAnimation_Params params;
	params.DeltaTimeX = DeltaTimeX;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function EnemySword_ABP.EnemySword_ABP_C.BlueprintInitializeAnimation
// (Event, Public, BlueprintEvent)
void UEnemySword_ABP_C::BlueprintInitializeAnimation()
{
	static auto fn = UObject::FindObject<UFunction>("Function EnemySword_ABP.EnemySword_ABP_C.BlueprintInitializeAnimation");

	UEnemySword_ABP_C_BlueprintInitializeAnimation_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function EnemySword_ABP.EnemySword_ABP_C.AnimNotify_AttackEnded
// (BlueprintCallable, BlueprintEvent)
void UEnemySword_ABP_C::AnimNotify_AttackEnded()
{
	static auto fn = UObject::FindObject<UFunction>("Function EnemySword_ABP.EnemySword_ABP_C.AnimNotify_AttackEnded");

	UEnemySword_ABP_C_AnimNotify_AttackEnded_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function EnemySword_ABP.EnemySword_ABP_C.AnimNotify_AttackNotify
// (BlueprintCallable, BlueprintEvent)
void UEnemySword_ABP_C::AnimNotify_AttackNotify()
{
	static auto fn = UObject::FindObject<UFunction>("Function EnemySword_ABP.EnemySword_ABP_C.AnimNotify_AttackNotify");

	UEnemySword_ABP_C_AnimNotify_AttackNotify_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function EnemySword_ABP.EnemySword_ABP_C.ExecuteUbergraph_EnemySword_ABP
// (Final)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UEnemySword_ABP_C::ExecuteUbergraph_EnemySword_ABP(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function EnemySword_ABP.EnemySword_ABP_C.ExecuteUbergraph_EnemySword_ABP");

	UEnemySword_ABP_C_ExecuteUbergraph_EnemySword_ABP_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
