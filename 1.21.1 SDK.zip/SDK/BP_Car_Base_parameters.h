#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BP_Car_Base.BP_Car_Base_C.fnRemoveHUD
struct ABP_Car_Base_C_fnRemoveHUD_Params
{
};

// Function BP_Car_Base.BP_Car_Base_C.fnRandomizeMaterial
struct ABP_Car_Base_C_fnRandomizeMaterial_Params
{
};

// Function BP_Car_Base.BP_Car_Base_C.fnCreateHUD
struct ABP_Car_Base_C_fnCreateHUD_Params
{
};

// Function BP_Car_Base.BP_Car_Base_C.Enable Incar View
struct ABP_Car_Base_C_Enable_Incar_View_Params
{
	bool                                               State;                                                     // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// Function BP_Car_Base.BP_Car_Base_C.InpActEvt_E_K2Node_InputKeyEvent_1
struct ABP_Car_Base_C_InpActEvt_E_K2Node_InputKeyEvent_1_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function BP_Car_Base.BP_Car_Base_C.InpActEvt_Handbrake_K2Node_InputActionEvent_2
struct ABP_Car_Base_C_InpActEvt_Handbrake_K2Node_InputActionEvent_2_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function BP_Car_Base.BP_Car_Base_C.InpActEvt_Handbrake_K2Node_InputActionEvent_1
struct ABP_Car_Base_C_InpActEvt_Handbrake_K2Node_InputActionEvent_1_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function BP_Car_Base.BP_Car_Base_C.EventCheckRendering
struct ABP_Car_Base_C_EventCheckRendering_Params
{
};

// Function BP_Car_Base.BP_Car_Base_C.ReceiveUnpossessed
struct ABP_Car_Base_C_ReceiveUnpossessed_Params
{
	class AController*                                 OldController;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function BP_Car_Base.BP_Car_Base_C.fnInteract
struct ABP_Car_Base_C_fnInteract_Params
{
	class AActor*                                      Reference_Actor;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function BP_Car_Base.BP_Car_Base_C.Right_K2Node_InputAxisEvent_2
struct ABP_Car_Base_C_Right_K2Node_InputAxisEvent_2_Params
{
	float                                              AxisValue;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function BP_Car_Base.BP_Car_Base_C.Down_K2Node_InputAxisEvent_1
struct ABP_Car_Base_C_Down_K2Node_InputAxisEvent_1_Params
{
	float                                              AxisValue;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function BP_Car_Base.BP_Car_Base_C.ReceiveBeginPlay
struct ABP_Car_Base_C_ReceiveBeginPlay_Params
{
};

// Function BP_Car_Base.BP_Car_Base_C.ReceiveTick
struct ABP_Car_Base_C_ReceiveTick_Params
{
	float                                              DeltaSeconds;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function BP_Car_Base.BP_Car_Base_C.BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
struct ABP_Car_Base_C_BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature_Params
{
	class UPrimitiveComponent*                         OverlappedComponent;                                       // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class AActor*                                      OtherActor;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UPrimitiveComponent*                         OtherComp;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	int                                                OtherBodyIndex;                                            // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                               bFromSweep;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	struct FHitResult                                  SweepResult;                                               // (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm, IsPlainOldData, NoDestructor, ContainsInstancedReference)
};

// Function BP_Car_Base.BP_Car_Base_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_16
struct ABP_Car_Base_C_InpAxisEvt_MoveRight_K2Node_InputAxisEvent_16_Params
{
	float                                              AxisValue;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function BP_Car_Base.BP_Car_Base_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_7
struct ABP_Car_Base_C_InpAxisEvt_MoveForward_K2Node_InputAxisEvent_7_Params
{
	float                                              AxisValue;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function BP_Car_Base.BP_Car_Base_C.EventUpdateHUD
struct ABP_Car_Base_C_EventUpdateHUD_Params
{
};

// Function BP_Car_Base.BP_Car_Base_C.ExecuteUbergraph_BP_Car_Base
struct ABP_Car_Base_C_ExecuteUbergraph_BP_Car_Base_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
