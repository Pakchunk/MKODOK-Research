#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass GroundedEntryState_AnimNotify.GroundedEntryState_AnimNotify_C
// 0x0001 (FullSize[0x0039] - InheritedSize[0x0038])
class UGroundedEntryState_AnimNotify_C : public UAnimNotify
{
public:
	TEnumAsByte<EGroundedEntryState>                   Grounded_Entry_State;                                      // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass GroundedEntryState_AnimNotify.GroundedEntryState_AnimNotify_C");
		return ptr;
	}



	struct FString GetNotifyName();
	bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
