// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function ALS_HUD.ALS_HUD_C.Get_AnimCurveValues
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FText                   ReturnValue                    (Parm, OutParm, ReturnParm)
struct FText UALS_HUD_C::Get_AnimCurveValues()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.Get_AnimCurveValues");

	UALS_HUD_C_Get_AnimCurveValues_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_HUD.ALS_HUD_C.Get_AnimCurveNames
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FText                   ReturnValue                    (Parm, OutParm, ReturnParm)
struct FText UALS_HUD_C::Get_AnimCurveNames()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.Get_AnimCurveNames");

	UALS_HUD_C_Get_AnimCurveNames_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_HUD.ALS_HUD_C.Get_CharacterStates
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FText                   ReturnValue                    (Parm, OutParm, ReturnParm)
struct FText UALS_HUD_C::Get_CharacterStates()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.Get_CharacterStates");

	UALS_HUD_C_Get_CharacterStates_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_HUD.ALS_HUD_C.Get_DebugCharacterName
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FText                   ReturnValue                    (Parm, OutParm, ReturnParm)
struct FText UALS_HUD_C::Get_DebugCharacterName()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.Get_DebugCharacterName");

	UALS_HUD_C_Get_DebugCharacterName_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_HUD.ALS_HUD_C.Get_ShowCharacterInfo_Color
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FSlateColor             ReturnValue                    (Parm, OutParm, ReturnParm)
struct FSlateColor UALS_HUD_C::Get_ShowCharacterInfo_Color()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.Get_ShowCharacterInfo_Color");

	UALS_HUD_C_Get_ShowCharacterInfo_Color_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_HUD.ALS_HUD_C.Get_ShowLayerColors_Color
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FSlateColor             ReturnValue                    (Parm, OutParm, ReturnParm)
struct FSlateColor UALS_HUD_C::Get_ShowLayerColors_Color()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.Get_ShowLayerColors_Color");

	UALS_HUD_C_Get_ShowLayerColors_Color_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_HUD.ALS_HUD_C.Get_ShowDebugShapes_Color
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FSlateColor             ReturnValue                    (Parm, OutParm, ReturnParm)
struct FSlateColor UALS_HUD_C::Get_ShowDebugShapes_Color()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.Get_ShowDebugShapes_Color");

	UALS_HUD_C_Get_ShowDebugShapes_Color_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_HUD.ALS_HUD_C.Get_ShowTraces_Color
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FSlateColor             ReturnValue                    (Parm, OutParm, ReturnParm)
struct FSlateColor UALS_HUD_C::Get_ShowTraces_Color()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.Get_ShowTraces_Color");

	UALS_HUD_C_Get_ShowTraces_Color_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_HUD.ALS_HUD_C.Get_DebugView_Color
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FSlateColor             ReturnValue                    (Parm, OutParm, ReturnParm)
struct FSlateColor UALS_HUD_C::Get_DebugView_Color()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.Get_DebugView_Color");

	UALS_HUD_C_Get_DebugView_Color_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_HUD.ALS_HUD_C.Get_Slomo_Color
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FSlateColor             ReturnValue                    (Parm, OutParm, ReturnParm)
struct FSlateColor UALS_HUD_C::Get_Slomo_Color()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.Get_Slomo_Color");

	UALS_HUD_C_Get_Slomo_Color_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_HUD.ALS_HUD_C.Get_ShowHUD_Color
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FSlateColor             ReturnValue                    (Parm, OutParm, ReturnParm)
struct FSlateColor UALS_HUD_C::Get_ShowHUD_Color()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.Get_ShowHUD_Color");

	UALS_HUD_C_Get_ShowHUD_Color_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_HUD.ALS_HUD_C.Get_CharacterInfo_Visibility
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// ESlateVisibility               ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
ESlateVisibility UALS_HUD_C::Get_CharacterInfo_Visibility()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.Get_CharacterInfo_Visibility");

	UALS_HUD_C_Get_CharacterInfo_Visibility_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_HUD.ALS_HUD_C.Get_HUD_Visibility
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// ESlateVisibility               ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
ESlateVisibility UALS_HUD_C::Get_HUD_Visibility()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.Get_HUD_Visibility");

	UALS_HUD_C_Get_HUD_Visibility_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_HUD.ALS_HUD_C.Tick
// (BlueprintCosmetic, Event, Public, BlueprintEvent)
// Parameters:
// struct FGeometry               MyGeometry                     (BlueprintVisible, BlueprintReadOnly, Parm, IsPlainOldData, NoDestructor)
// float                          InDeltaTime                    (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UALS_HUD_C::Tick(const struct FGeometry& MyGeometry, float InDeltaTime)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.Tick");

	UALS_HUD_C_Tick_Params params;
	params.MyGeometry = MyGeometry;
	params.InDeltaTime = InDeltaTime;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_HUD.ALS_HUD_C.ExecuteUbergraph_ALS_HUD
// (Final, HasDefaults)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UALS_HUD_C::ExecuteUbergraph_ALS_HUD(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_HUD.ALS_HUD_C.ExecuteUbergraph_ALS_HUD");

	UALS_HUD_C_ExecuteUbergraph_ALS_HUD_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
