#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.MantleStart
struct AALS_AnimMan_CharacterBP_C_MantleStart_Params
{
	float                                              MantleHeight;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FALS_ComponentAndTransform                  MantleLedgeWS;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, IsPlainOldData, NoDestructor, ContainsInstancedReference, HasGetValueTypeHash)
	TEnumAsByte<EMantleType>                           MantleType;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UpdateHeldObjectAnimations
struct AALS_AnimMan_CharacterBP_C_UpdateHeldObjectAnimations_Params
{
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.RagdollEnd
struct AALS_AnimMan_CharacterBP_C_RagdollEnd_Params
{
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.RagdollStart
struct AALS_AnimMan_CharacterBP_C_RagdollStart_Params
{
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.GetGetUpAnimation
struct AALS_AnimMan_CharacterBP_C_GetGetUpAnimation_Params
{
	bool                                               RagdollFaceUp;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	class UAnimMontage*                                ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.MantleEnd
struct AALS_AnimMan_CharacterBP_C_MantleEnd_Params
{
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.GetRollAnimation
struct AALS_AnimMan_CharacterBP_C_GetRollAnimation_Params
{
	class UAnimMontage*                                ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.OnOverlayStateChanged
struct AALS_AnimMan_CharacterBP_C_OnOverlayStateChanged_Params
{
	TEnumAsByte<EALS_OverlayState>                     NewOverlayState;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.BPI_Get_3P_TraceParams
struct AALS_AnimMan_CharacterBP_C_BPI_Get_3P_TraceParams_Params
{
	struct FVector                                     TraceOrigin;                                               // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              TraceRadius;                                               // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<ETraceTypeQuery>                       TraceChannel;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.GetMantleAsset
struct AALS_AnimMan_CharacterBP_C_GetMantleAsset_Params
{
	TEnumAsByte<EMantleType>                           MantleType;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FMantle_Asset                               ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UpdateLayeringColors
struct AALS_AnimMan_CharacterBP_C_UpdateLayeringColors_Params
{
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UpdateColoringSystem
struct AALS_AnimMan_CharacterBP_C_UpdateColoringSystem_Params
{
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.ResetColors
struct AALS_AnimMan_CharacterBP_C_ResetColors_Params
{
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.SetDynamicMaterials
struct AALS_AnimMan_CharacterBP_C_SetDynamicMaterials_Params
{
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.BPI_Get_FP_CameraTarget
struct AALS_AnimMan_CharacterBP_C_BPI_Get_FP_CameraTarget_Params
{
	struct FVector                                     ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.BPI_Get_3P_PivotTarget
struct AALS_AnimMan_CharacterBP_C_BPI_Get_3P_PivotTarget_Params
{
	struct FTransform                                  ReturnValue;                                               // (Parm, OutParm, ReturnParm, IsPlainOldData, NoDestructor)
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.AttachToHand
struct AALS_AnimMan_CharacterBP_C_AttachToHand_Params
{
	class UStaticMesh*                                 NewStaticMesh;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                               NewSkeletalMesh;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UClass*                                      NewAnimClass;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                               LeftHand;                                                  // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	struct FVector                                     Offset;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.ClearHeldObject
struct AALS_AnimMan_CharacterBP_C_ClearHeldObject_Params
{
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UpdateHeldObject
struct AALS_AnimMan_CharacterBP_C_UpdateHeldObject_Params
{
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UserConstructionScript
struct AALS_AnimMan_CharacterBP_C_UserConstructionScript_Params
{
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.InpActEvt_M_K2Node_InputKeyEvent_1
struct AALS_AnimMan_CharacterBP_C_InpActEvt_M_K2Node_InputKeyEvent_1_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.ReceiveTick
struct AALS_AnimMan_CharacterBP_C_ReceiveTick_Params
{
	float                                              DeltaSeconds;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.ExecuteUbergraph_ALS_AnimMan_CharacterBP
struct AALS_AnimMan_CharacterBP_C_ExecuteUbergraph_ALS_AnimMan_CharacterBP_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
