// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function ALS_Player_Controller.ALS_Player_Controller_C.BPI_Get_DebugInfo
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
// class ACharacter*              DebugFocusCharacter            (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                           DebugView                      (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                           ShowHUD                        (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                           ShowTraces                     (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                           ShowDebugShapes                (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                           ShowLayerColors                (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                           Slomo                          (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                           ShowCharacterInfo              (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
void AALS_Player_Controller_C::BPI_Get_DebugInfo(class ACharacter** DebugFocusCharacter, bool* DebugView, bool* ShowHUD, bool* ShowTraces, bool* ShowDebugShapes, bool* ShowLayerColors, bool* Slomo, bool* ShowCharacterInfo)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.BPI_Get_DebugInfo");

	AALS_Player_Controller_C_BPI_Get_DebugInfo_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (DebugFocusCharacter != nullptr)
		*DebugFocusCharacter = params.DebugFocusCharacter;
	if (DebugView != nullptr)
		*DebugView = params.DebugView;
	if (ShowHUD != nullptr)
		*ShowHUD = params.ShowHUD;
	if (ShowTraces != nullptr)
		*ShowTraces = params.ShowTraces;
	if (ShowDebugShapes != nullptr)
		*ShowDebugShapes = params.ShowDebugShapes;
	if (ShowLayerColors != nullptr)
		*ShowLayerColors = params.ShowLayerColors;
	if (Slomo != nullptr)
		*Slomo = params.Slomo;
	if (ShowCharacterInfo != nullptr)
		*ShowCharacterInfo = params.ShowCharacterInfo;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Tab_K2Node_InputKeyEvent_9
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Player_Controller_C::InpActEvt_Tab_K2Node_InputKeyEvent_9(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Tab_K2Node_InputKeyEvent_9");

	AALS_Player_Controller_C_InpActEvt_Tab_K2Node_InputKeyEvent_9_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_T_K2Node_InputKeyEvent_8
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Player_Controller_C::InpActEvt_T_K2Node_InputKeyEvent_8(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_T_K2Node_InputKeyEvent_8");

	AALS_Player_Controller_C_InpActEvt_T_K2Node_InputKeyEvent_8_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Y_K2Node_InputKeyEvent_7
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Player_Controller_C::InpActEvt_Y_K2Node_InputKeyEvent_7(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Y_K2Node_InputKeyEvent_7");

	AALS_Player_Controller_C_InpActEvt_Y_K2Node_InputKeyEvent_7_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_I_K2Node_InputKeyEvent_6
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Player_Controller_C::InpActEvt_I_K2Node_InputKeyEvent_6(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_I_K2Node_InputKeyEvent_6");

	AALS_Player_Controller_C_InpActEvt_I_K2Node_InputKeyEvent_6_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Comma_K2Node_InputKeyEvent_5
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Player_Controller_C::InpActEvt_Comma_K2Node_InputKeyEvent_5(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Comma_K2Node_InputKeyEvent_5");

	AALS_Player_Controller_C_InpActEvt_Comma_K2Node_InputKeyEvent_5_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Period_K2Node_InputKeyEvent_4
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Player_Controller_C::InpActEvt_Period_K2Node_InputKeyEvent_4(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Period_K2Node_InputKeyEvent_4");

	AALS_Player_Controller_C_InpActEvt_Period_K2Node_InputKeyEvent_4_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_U_K2Node_InputKeyEvent_3
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Player_Controller_C::InpActEvt_U_K2Node_InputKeyEvent_3(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_U_K2Node_InputKeyEvent_3");

	AALS_Player_Controller_C_InpActEvt_U_K2Node_InputKeyEvent_3_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_V_K2Node_InputKeyEvent_2
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Player_Controller_C::InpActEvt_V_K2Node_InputKeyEvent_2(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_V_K2Node_InputKeyEvent_2");

	AALS_Player_Controller_C_InpActEvt_V_K2Node_InputKeyEvent_2_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_OpenOverlayMenu_K2Node_InputActionEvent_4
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Player_Controller_C::InpActEvt_OpenOverlayMenu_K2Node_InputActionEvent_4(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_OpenOverlayMenu_K2Node_InputActionEvent_4");

	AALS_Player_Controller_C_InpActEvt_OpenOverlayMenu_K2Node_InputActionEvent_4_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_OpenOverlayMenu_K2Node_InputActionEvent_3
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Player_Controller_C::InpActEvt_OpenOverlayMenu_K2Node_InputActionEvent_3(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_OpenOverlayMenu_K2Node_InputActionEvent_3");

	AALS_Player_Controller_C_InpActEvt_OpenOverlayMenu_K2Node_InputActionEvent_3_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_CycleOverlayUp_K2Node_InputActionEvent_2
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Player_Controller_C::InpActEvt_CycleOverlayUp_K2Node_InputActionEvent_2(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_CycleOverlayUp_K2Node_InputActionEvent_2");

	AALS_Player_Controller_C_InpActEvt_CycleOverlayUp_K2Node_InputActionEvent_2_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_CycleOverlayDown_K2Node_InputActionEvent_1
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Player_Controller_C::InpActEvt_CycleOverlayDown_K2Node_InputActionEvent_1(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_CycleOverlayDown_K2Node_InputActionEvent_1");

	AALS_Player_Controller_C_InpActEvt_CycleOverlayDown_K2Node_InputActionEvent_1_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Z_K2Node_InputKeyEvent_1
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Player_Controller_C::InpActEvt_Z_K2Node_InputKeyEvent_1(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Z_K2Node_InputKeyEvent_1");

	AALS_Player_Controller_C_InpActEvt_Z_K2Node_InputKeyEvent_1_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.ReceivePossess
// (Event, Protected, BlueprintEvent)
// Parameters:
// class APawn*                   PossessedPawn                  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Player_Controller_C::ReceivePossess(class APawn* PossessedPawn)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.ReceivePossess");

	AALS_Player_Controller_C_ReceivePossess_Params params;
	params.PossessedPawn = PossessedPawn;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.ReceiveBeginPlay
// (Event, Protected, BlueprintEvent)
void AALS_Player_Controller_C::ReceiveBeginPlay()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.ReceiveBeginPlay");

	AALS_Player_Controller_C_ReceiveBeginPlay_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Player_Controller.ALS_Player_Controller_C.ExecuteUbergraph_ALS_Player_Controller
// (Final, HasDefaults)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Player_Controller_C::ExecuteUbergraph_ALS_Player_Controller(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Player_Controller.ALS_Player_Controller_C.ExecuteUbergraph_ALS_Player_Controller");

	AALS_Player_Controller_C_ExecuteUbergraph_ALS_Player_Controller_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
