// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.MantleStart
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// float                          MantleHeight                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FALS_ComponentAndTransform MantleLedgeWS                  (BlueprintVisible, BlueprintReadOnly, Parm, IsPlainOldData, NoDestructor, ContainsInstancedReference, HasGetValueTypeHash)
// TEnumAsByte<EMantleType>       MantleType                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_AnimMan_CharacterBP_C::MantleStart(float MantleHeight, const struct FALS_ComponentAndTransform& MantleLedgeWS, TEnumAsByte<EMantleType> MantleType)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.MantleStart");

	AALS_AnimMan_CharacterBP_C_MantleStart_Params params;
	params.MantleHeight = MantleHeight;
	params.MantleLedgeWS = MantleLedgeWS;
	params.MantleType = MantleType;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UpdateHeldObjectAnimations
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_AnimMan_CharacterBP_C::UpdateHeldObjectAnimations()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UpdateHeldObjectAnimations");

	AALS_AnimMan_CharacterBP_C_UpdateHeldObjectAnimations_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.RagdollEnd
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_AnimMan_CharacterBP_C::RagdollEnd()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.RagdollEnd");

	AALS_AnimMan_CharacterBP_C_RagdollEnd_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.RagdollStart
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_AnimMan_CharacterBP_C::RagdollStart()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.RagdollStart");

	AALS_AnimMan_CharacterBP_C_RagdollStart_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.GetGetUpAnimation
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// bool                           RagdollFaceUp                  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
// class UAnimMontage*            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
class UAnimMontage* AALS_AnimMan_CharacterBP_C::GetGetUpAnimation(bool RagdollFaceUp)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.GetGetUpAnimation");

	AALS_AnimMan_CharacterBP_C_GetGetUpAnimation_Params params;
	params.RagdollFaceUp = RagdollFaceUp;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.MantleEnd
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_AnimMan_CharacterBP_C::MantleEnd()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.MantleEnd");

	AALS_AnimMan_CharacterBP_C_MantleEnd_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.GetRollAnimation
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// class UAnimMontage*            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
class UAnimMontage* AALS_AnimMan_CharacterBP_C::GetRollAnimation()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.GetRollAnimation");

	AALS_AnimMan_CharacterBP_C_GetRollAnimation_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.OnOverlayStateChanged
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_OverlayState> NewOverlayState                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_AnimMan_CharacterBP_C::OnOverlayStateChanged(TEnumAsByte<EALS_OverlayState> NewOverlayState)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.OnOverlayStateChanged");

	AALS_AnimMan_CharacterBP_C_OnOverlayStateChanged_Params params;
	params.NewOverlayState = NewOverlayState;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.BPI_Get_3P_TraceParams
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FVector                 TraceOrigin                    (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          TraceRadius                    (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<ETraceTypeQuery>   TraceChannel                   (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_AnimMan_CharacterBP_C::BPI_Get_3P_TraceParams(struct FVector* TraceOrigin, float* TraceRadius, TEnumAsByte<ETraceTypeQuery>* TraceChannel)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.BPI_Get_3P_TraceParams");

	AALS_AnimMan_CharacterBP_C_BPI_Get_3P_TraceParams_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (TraceOrigin != nullptr)
		*TraceOrigin = params.TraceOrigin;
	if (TraceRadius != nullptr)
		*TraceRadius = params.TraceRadius;
	if (TraceChannel != nullptr)
		*TraceChannel = params.TraceChannel;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.GetMantleAsset
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// TEnumAsByte<EMantleType>       MantleType                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FMantle_Asset           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
struct FMantle_Asset AALS_AnimMan_CharacterBP_C::GetMantleAsset(TEnumAsByte<EMantleType> MantleType)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.GetMantleAsset");

	AALS_AnimMan_CharacterBP_C_GetMantleAsset_Params params;
	params.MantleType = MantleType;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UpdateLayeringColors
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_AnimMan_CharacterBP_C::UpdateLayeringColors()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UpdateLayeringColors");

	AALS_AnimMan_CharacterBP_C_UpdateLayeringColors_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UpdateColoringSystem
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_AnimMan_CharacterBP_C::UpdateColoringSystem()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UpdateColoringSystem");

	AALS_AnimMan_CharacterBP_C_UpdateColoringSystem_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.ResetColors
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_AnimMan_CharacterBP_C::ResetColors()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.ResetColors");

	AALS_AnimMan_CharacterBP_C_ResetColors_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.SetDynamicMaterials
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_AnimMan_CharacterBP_C::SetDynamicMaterials()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.SetDynamicMaterials");

	AALS_AnimMan_CharacterBP_C_SetDynamicMaterials_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.BPI_Get_FP_CameraTarget
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FVector                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
struct FVector AALS_AnimMan_CharacterBP_C::BPI_Get_FP_CameraTarget()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.BPI_Get_FP_CameraTarget");

	AALS_AnimMan_CharacterBP_C_BPI_Get_FP_CameraTarget_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.BPI_Get_3P_PivotTarget
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FTransform              ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData, NoDestructor)
struct FTransform AALS_AnimMan_CharacterBP_C::BPI_Get_3P_PivotTarget()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.BPI_Get_3P_PivotTarget");

	AALS_AnimMan_CharacterBP_C_BPI_Get_3P_PivotTarget_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.AttachToHand
// (Public, HasDefaults, BlueprintCallable, BlueprintEvent)
// Parameters:
// class UStaticMesh*             NewStaticMesh                  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// class USkeletalMesh*           NewSkeletalMesh                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// class UClass*                  NewAnimClass                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                           LeftHand                       (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
// struct FVector                 Offset                         (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_AnimMan_CharacterBP_C::AttachToHand(class UStaticMesh* NewStaticMesh, class USkeletalMesh* NewSkeletalMesh, class UClass* NewAnimClass, bool LeftHand, const struct FVector& Offset)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.AttachToHand");

	AALS_AnimMan_CharacterBP_C_AttachToHand_Params params;
	params.NewStaticMesh = NewStaticMesh;
	params.NewSkeletalMesh = NewSkeletalMesh;
	params.NewAnimClass = NewAnimClass;
	params.LeftHand = LeftHand;
	params.Offset = Offset;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.ClearHeldObject
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_AnimMan_CharacterBP_C::ClearHeldObject()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.ClearHeldObject");

	AALS_AnimMan_CharacterBP_C_ClearHeldObject_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UpdateHeldObject
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_AnimMan_CharacterBP_C::UpdateHeldObject()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UpdateHeldObject");

	AALS_AnimMan_CharacterBP_C_UpdateHeldObject_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UserConstructionScript
// (Event, Public, BlueprintCallable, BlueprintEvent)
void AALS_AnimMan_CharacterBP_C::UserConstructionScript()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.UserConstructionScript");

	AALS_AnimMan_CharacterBP_C_UserConstructionScript_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.InpActEvt_M_K2Node_InputKeyEvent_1
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_AnimMan_CharacterBP_C::InpActEvt_M_K2Node_InputKeyEvent_1(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.InpActEvt_M_K2Node_InputKeyEvent_1");

	AALS_AnimMan_CharacterBP_C_InpActEvt_M_K2Node_InputKeyEvent_1_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.ReceiveTick
// (Event, Public, BlueprintEvent)
// Parameters:
// float                          DeltaSeconds                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_AnimMan_CharacterBP_C::ReceiveTick(float DeltaSeconds)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.ReceiveTick");

	AALS_AnimMan_CharacterBP_C_ReceiveTick_Params params;
	params.DeltaSeconds = DeltaSeconds;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.ExecuteUbergraph_ALS_AnimMan_CharacterBP
// (Final, HasDefaults)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_AnimMan_CharacterBP_C::ExecuteUbergraph_ALS_AnimMan_CharacterBP(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_AnimMan_CharacterBP.ALS_AnimMan_CharacterBP_C.ExecuteUbergraph_ALS_AnimMan_CharacterBP");

	AALS_AnimMan_CharacterBP_C_ExecuteUbergraph_ALS_AnimMan_CharacterBP_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
