#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ALS_DemoLevel.ALS_DemoLevel_C.InpActEvt_One_K2Node_InputKeyEvent_2
struct AALS_DemoLevel_C_InpActEvt_One_K2Node_InputKeyEvent_2_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_DemoLevel.ALS_DemoLevel_C.InpActEvt_Escape_K2Node_InputKeyEvent_1
struct AALS_DemoLevel_C_InpActEvt_Escape_K2Node_InputKeyEvent_1_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_DemoLevel.ALS_DemoLevel_C.ReceiveBeginPlay
struct AALS_DemoLevel_C_ReceiveBeginPlay_Params
{
};

// Function ALS_DemoLevel.ALS_DemoLevel_C.BndEvt__TriggerBox_1_K2Node_ActorBoundEvent_0_ActorBeginOverlapSignature__DelegateSignature
struct AALS_DemoLevel_C_BndEvt__TriggerBox_1_K2Node_ActorBoundEvent_0_ActorBeginOverlapSignature__DelegateSignature_Params
{
	class AActor*                                      OverlappedActor;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class AActor*                                      OtherActor;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_DemoLevel.ALS_DemoLevel_C.BndEvt__TriggerBox2_3_K2Node_ActorBoundEvent_3_ActorBeginOverlapSignature__DelegateSignature
struct AALS_DemoLevel_C_BndEvt__TriggerBox2_3_K2Node_ActorBoundEvent_3_ActorBeginOverlapSignature__DelegateSignature_Params
{
	class AActor*                                      OverlappedActor;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class AActor*                                      OtherActor;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_DemoLevel.ALS_DemoLevel_C.ExecuteUbergraph_ALS_DemoLevel
struct AALS_DemoLevel_C_ExecuteUbergraph_ALS_DemoLevel_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
