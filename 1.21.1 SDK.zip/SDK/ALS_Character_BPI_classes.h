#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass ALS_Character_BPI.ALS_Character_BPI_C
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UALS_Character_BPI_C : public UInterface
{
public:


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass ALS_Character_BPI.ALS_Character_BPI_C");
		return ptr;
	}



	void BPI_Set_OverlayState(TEnumAsByte<EALS_OverlayState> NewOverlayState);
	void BPI_Set_ViewMode(TEnumAsByte<EALS_ViewMode> NewViewMode);
	void BPI_Set_Gait(TEnumAsByte<EALS_Gait> NewGait);
	void BPI_Set_RotationMode(TEnumAsByte<EALS_RotationMode> NewRotationMode);
	void BPI_Set_MovementAction(TEnumAsByte<EALS_MovementAction> NewMovementAction);
	void BPI_Set_MovementState(TEnumAsByte<EALS_MovementState> NewMovementState);
	void BPI_Get_EssentialValues(struct FVector* Velocity, struct FVector* Acceleration, struct FVector* MovementInput, bool* IsMoving, bool* HasMovementInput, float* Speed, float* MovementInputAmount, struct FRotator* AimingRotation, float* AimYawRate);
	void BPI_Get_CurrentStates(TEnumAsByte<EMovementMode>* PawnMovementMode, TEnumAsByte<EALS_MovementState>* MovementState, TEnumAsByte<EALS_MovementState>* PrevMovementState, TEnumAsByte<EALS_MovementAction>* MovementAction, TEnumAsByte<EALS_RotationMode>* RotationMode, TEnumAsByte<EALS_Gait>* ActualGait, TEnumAsByte<EALS_Stance>* ActualStance, TEnumAsByte<EALS_ViewMode>* ViewMode, TEnumAsByte<EALS_OverlayState>* OverlayState);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
