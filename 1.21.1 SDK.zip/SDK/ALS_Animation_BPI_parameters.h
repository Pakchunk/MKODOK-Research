#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ALS_Animation_BPI.ALS_Animation_BPI_C.BPI_SetOverlayOverrideState
struct UALS_Animation_BPI_C_BPI_SetOverlayOverrideState_Params
{
	int                                                OverlayOverrideState;                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Animation_BPI.ALS_Animation_BPI_C.BPI_SetGroundedEntryState
struct UALS_Animation_BPI_C_BPI_SetGroundedEntryState_Params
{
	TEnumAsByte<EGroundedEntryState>                   GroundedEntryState;                                        // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Animation_BPI.ALS_Animation_BPI_C.BPI_Jumped
struct UALS_Animation_BPI_C_BPI_Jumped_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
