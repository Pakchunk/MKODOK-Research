#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_OverlayState
struct UALS_Character_BPI_C_BPI_Set_OverlayState_Params
{
	TEnumAsByte<EALS_OverlayState>                     NewOverlayState;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_ViewMode
struct UALS_Character_BPI_C_BPI_Set_ViewMode_Params
{
	TEnumAsByte<EALS_ViewMode>                         NewViewMode;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_Gait
struct UALS_Character_BPI_C_BPI_Set_Gait_Params
{
	TEnumAsByte<EALS_Gait>                             NewGait;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_RotationMode
struct UALS_Character_BPI_C_BPI_Set_RotationMode_Params
{
	TEnumAsByte<EALS_RotationMode>                     NewRotationMode;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_MovementAction
struct UALS_Character_BPI_C_BPI_Set_MovementAction_Params
{
	TEnumAsByte<EALS_MovementAction>                   NewMovementAction;                                         // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_MovementState
struct UALS_Character_BPI_C_BPI_Set_MovementState_Params
{
	TEnumAsByte<EALS_MovementState>                    NewMovementState;                                          // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Get_EssentialValues
struct UALS_Character_BPI_C_BPI_Get_EssentialValues_Params
{
	struct FVector                                     Velocity;                                                  // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                                     Acceleration;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                                     MovementInput;                                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                               IsMoving;                                                  // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                               HasMovementInput;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	float                                              Speed;                                                     // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              MovementInputAmount;                                       // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FRotator                                    AimingRotation;                                            // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	float                                              AimYawRate;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Get_CurrentStates
struct UALS_Character_BPI_C_BPI_Get_CurrentStates_Params
{
	TEnumAsByte<EMovementMode>                         PawnMovementMode;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_MovementState>                    MovementState;                                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_MovementState>                    PrevMovementState;                                         // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_MovementAction>                   MovementAction;                                            // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_RotationMode>                     RotationMode;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_Gait>                             ActualGait;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_Stance>                           ActualStance;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_ViewMode>                         ViewMode;                                                  // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_OverlayState>                     OverlayState;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
