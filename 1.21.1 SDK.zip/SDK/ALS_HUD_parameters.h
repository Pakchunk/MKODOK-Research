#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ALS_HUD.ALS_HUD_C.Get_AnimCurveValues
struct UALS_HUD_C_Get_AnimCurveValues_Params
{
	struct FText                                       ReturnValue;                                               // (Parm, OutParm, ReturnParm)
};

// Function ALS_HUD.ALS_HUD_C.Get_AnimCurveNames
struct UALS_HUD_C_Get_AnimCurveNames_Params
{
	struct FText                                       ReturnValue;                                               // (Parm, OutParm, ReturnParm)
};

// Function ALS_HUD.ALS_HUD_C.Get_CharacterStates
struct UALS_HUD_C_Get_CharacterStates_Params
{
	struct FText                                       ReturnValue;                                               // (Parm, OutParm, ReturnParm)
};

// Function ALS_HUD.ALS_HUD_C.Get_DebugCharacterName
struct UALS_HUD_C_Get_DebugCharacterName_Params
{
	struct FText                                       ReturnValue;                                               // (Parm, OutParm, ReturnParm)
};

// Function ALS_HUD.ALS_HUD_C.Get_ShowCharacterInfo_Color
struct UALS_HUD_C_Get_ShowCharacterInfo_Color_Params
{
	struct FSlateColor                                 ReturnValue;                                               // (Parm, OutParm, ReturnParm)
};

// Function ALS_HUD.ALS_HUD_C.Get_ShowLayerColors_Color
struct UALS_HUD_C_Get_ShowLayerColors_Color_Params
{
	struct FSlateColor                                 ReturnValue;                                               // (Parm, OutParm, ReturnParm)
};

// Function ALS_HUD.ALS_HUD_C.Get_ShowDebugShapes_Color
struct UALS_HUD_C_Get_ShowDebugShapes_Color_Params
{
	struct FSlateColor                                 ReturnValue;                                               // (Parm, OutParm, ReturnParm)
};

// Function ALS_HUD.ALS_HUD_C.Get_ShowTraces_Color
struct UALS_HUD_C_Get_ShowTraces_Color_Params
{
	struct FSlateColor                                 ReturnValue;                                               // (Parm, OutParm, ReturnParm)
};

// Function ALS_HUD.ALS_HUD_C.Get_DebugView_Color
struct UALS_HUD_C_Get_DebugView_Color_Params
{
	struct FSlateColor                                 ReturnValue;                                               // (Parm, OutParm, ReturnParm)
};

// Function ALS_HUD.ALS_HUD_C.Get_Slomo_Color
struct UALS_HUD_C_Get_Slomo_Color_Params
{
	struct FSlateColor                                 ReturnValue;                                               // (Parm, OutParm, ReturnParm)
};

// Function ALS_HUD.ALS_HUD_C.Get_ShowHUD_Color
struct UALS_HUD_C_Get_ShowHUD_Color_Params
{
	struct FSlateColor                                 ReturnValue;                                               // (Parm, OutParm, ReturnParm)
};

// Function ALS_HUD.ALS_HUD_C.Get_CharacterInfo_Visibility
struct UALS_HUD_C_Get_CharacterInfo_Visibility_Params
{
	ESlateVisibility                                   ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_HUD.ALS_HUD_C.Get_HUD_Visibility
struct UALS_HUD_C_Get_HUD_Visibility_Params
{
	ESlateVisibility                                   ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_HUD.ALS_HUD_C.Tick
struct UALS_HUD_C_Tick_Params
{
	struct FGeometry                                   MyGeometry;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, IsPlainOldData, NoDestructor)
	float                                              InDeltaTime;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_HUD.ALS_HUD_C.ExecuteUbergraph_ALS_HUD
struct UALS_HUD_C_ExecuteUbergraph_ALS_HUD_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
