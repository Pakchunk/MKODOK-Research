#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BP_Sky_Sphere.BP_Sky_Sphere_C.RefreshMaterial
struct ABP_Sky_Sphere_C_RefreshMaterial_Params
{
};

// Function BP_Sky_Sphere.BP_Sky_Sphere_C.UpdateSunDirection
struct ABP_Sky_Sphere_C_UpdateSunDirection_Params
{
};

// Function BP_Sky_Sphere.BP_Sky_Sphere_C.UserConstructionScript
struct ABP_Sky_Sphere_C_UserConstructionScript_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
