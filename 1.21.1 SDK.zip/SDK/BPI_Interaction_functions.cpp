// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function BPI_Interaction.BPI_Interaction_C.fnInteract
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// class AActor*                  Reference_Actor                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UBPI_Interaction_C::fnInteract(class AActor* Reference_Actor)
{
	static auto fn = UObject::FindObject<UFunction>("Function BPI_Interaction.BPI_Interaction_C.fnInteract");

	UBPI_Interaction_C_fnInteract_Params params;
	params.Reference_Actor = Reference_Actor;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
