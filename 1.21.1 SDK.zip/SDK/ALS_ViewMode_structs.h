#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// UserDefinedEnum ALS_ViewMode.ALS_ViewMode
enum class EALS_ViewMode : uint8_t
{
	ALS_ViewMode__NewEnumerator0   = 0,
	ALS_ViewMode__NewEnumerator1   = 1,
	ALS_ViewMode__ALS_MAX          = 2,

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
