#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass ALS_Base_CharacterBP.ALS_Base_CharacterBP_C
// 0x02F1 (FullSize[0x07A9] - InheritedSize[0x04B8])
class AALS_Base_CharacterBP_C : public ACharacter
{
public:
	unsigned char                                      UnknownData_LKT7[0x8];                                     // 0x04B8(0x0008) Fix Super Size
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                            // 0x04C0(0x0008) (ZeroConstructor, Transient, DuplicateTransient)
	float                                              MantleTimeline_BlendIn_91D7A42A4A23268AEE2E28853DEE703D;   // 0x04C8(0x0004) (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<ETimelineDirection>                    MantleTimeline__Direction_91D7A42A4A23268AEE2E28853DEE703D; // 0x04CC(0x0001) (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	unsigned char                                      UnknownData_OMVC[0x3];                                     // 0x04CD(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	class UTimelineComponent*                          MantleTimeline;                                            // 0x04D0(0x0008) (BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_MovementState>                    MovementState;                                             // 0x04D8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_MovementState>                    PrevMovementState;                                         // 0x04D9(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_RotationMode>                     DesiredRotationMode;                                       // 0x04DA(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_MovementAction>                   MovementAction;                                            // 0x04DB(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_RotationMode>                     RotationMode;                                              // 0x04DC(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_Gait>                             DesiredGait;                                               // 0x04DD(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_Gait>                             Gait;                                                      // 0x04DE(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_Stance>                           Stance;                                                    // 0x04DF(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_ViewMode>                         ViewMode;                                                  // 0x04E0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	unsigned char                                      UnknownData_OZ04[0x3];                                     // 0x04E1(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	struct FVector                                     PreviousVelocity;                                          // 0x04E4(0x000C) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                                     Acceleration;                                              // 0x04F0(0x000C) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                               IsMoving;                                                  // 0x04FC(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                               HasMovementInput;                                          // 0x04FD(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	unsigned char                                      UnknownData_7RYJ[0x2];                                     // 0x04FE(0x0002) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	struct FRotator                                    LastVelocityRotation;                                      // 0x0500(0x000C) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	struct FRotator                                    LastMovementInputRotation;                                 // 0x050C(0x000C) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	float                                              Speed;                                                     // 0x0518(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              MovementInputAmount;                                       // 0x051C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              PreviousAimYaw;                                            // 0x0520(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FRotator                                    TargetRotation;                                            // 0x0524(0x000C) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	struct FRotator                                    InAirRotation;                                             // 0x0530(0x000C) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	float                                              YawOffset;                                                 // 0x053C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FDataTableRowHandle                         MovementModel;                                             // 0x0540(0x0010) (Edit, BlueprintVisible, NoDestructor)
	struct FMovementSettings_State                     MovementData;                                              // 0x0550(0x00C0) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FMovementSettings                           CurrentMovementSettings;                                   // 0x0610(0x0020) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FMantle_Params                              MantleParams;                                              // 0x0630(0x0028) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	unsigned char                                      UnknownData_AWW3[0x8];                                     // 0x0658(0x0008) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	struct FALS_ComponentAndTransform                  MantleLedgeLS;                                             // 0x0660(0x0040) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData, NoDestructor, ContainsInstancedReference, HasGetValueTypeHash)
	struct FTransform                                  MantleTarget;                                              // 0x06A0(0x0030) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	struct FTransform                                  MantleActualStartOffset;                                   // 0x06D0(0x0030) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	struct FTransform                                  MantleAnimatedStartOffset;                                 // 0x0700(0x0030) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	struct FMantle_TraceSettings                       GroundedTraceSettings;                                     // 0x0730(0x0014) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FMantle_TraceSettings                       AutomaticTraceSettings;                                    // 0x0744(0x0014) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FMantle_TraceSettings                       FallingTraceSettings;                                      // 0x0758(0x0014) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_Stance>                           DesiredStance;                                             // 0x076C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	unsigned char                                      UnknownData_8YTM[0x3];                                     // 0x076D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	float                                              DownRate;                                                  // 0x0770(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              LookLeftRightRate;                                         // 0x0774(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              AimYawRate;                                                // 0x0778(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_OverlayState>                     OverlayState;                                              // 0x077C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	unsigned char                                      UnknownData_UDD8[0x3];                                     // 0x077D(0x0003) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	int                                                TimesPressedStance;                                        // 0x0780(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                               BreakFall;                                                 // 0x0784(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                               SprintHeld;                                                // 0x0785(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	unsigned char                                      UnknownData_KUNT[0x2];                                     // 0x0786(0x0002) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	class UAnimInstance*                               MainAnimInstance;                                          // 0x0788(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                               RagdollOnGround;                                           // 0x0790(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                               RagdollFaceUp;                                             // 0x0791(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	unsigned char                                      UnknownData_GBOG[0x2];                                     // 0x0792(0x0002) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	struct FVector                                     LastRagdollVelocity;                                       // 0x0794(0x000C) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              ThirdPersonFOV;                                            // 0x07A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              FirstPersonFOV;                                            // 0x07A4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                               RightShoulder;                                             // 0x07A8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor)


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass ALS_Base_CharacterBP.ALS_Base_CharacterBP_C");
		return ptr;
	}



	void BPI_Get_CameraParameters(float* TP_FOV, float* FP_FOV, bool* RightShoulder);
	void BPI_Get_3P_TraceParams(struct FVector* TraceOrigin, float* TraceRadius, TEnumAsByte<ETraceTypeQuery>* TraceChannel);
	struct FTransform BPI_Get_3P_PivotTarget();
	struct FVector BPI_Get_FP_CameraTarget();
	void BPI_Get_EssentialValues(struct FVector* Velocity, struct FVector* Acceleration, struct FVector* MovementInput, bool* IsMoving, bool* HasMovementInput, float* Speed, float* MovementInputAmount, struct FRotator* AimingRotation, float* AimYawRate);
	void BPI_Get_CurrentStates(TEnumAsByte<EMovementMode>* PawnMovementMode, TEnumAsByte<EALS_MovementState>* MovementState, TEnumAsByte<EALS_MovementState>* PrevMovementState, TEnumAsByte<EALS_MovementAction>* MovementAction, TEnumAsByte<EALS_RotationMode>* RotationMode, TEnumAsByte<EALS_Gait>* ActualGait, TEnumAsByte<EALS_Stance>* ActualStance, TEnumAsByte<EALS_ViewMode>* ViewMode, TEnumAsByte<EALS_OverlayState>* OverlayState);
	class UAnimMontage* GetGetUpAnimation(bool RagdollFaceUp);
	class UAnimMontage* GetRollAnimation();
	float GetMappedSpeed();
	bool CanUpdateMovingRotation();
	void OnOverlayStateChanged(TEnumAsByte<EALS_OverlayState> NewOverlayState);
	void OnViewModeChanged(TEnumAsByte<EALS_ViewMode> NewViewMode);
	void OnGaitChanged(TEnumAsByte<EALS_Gait> NewActualGait);
	void OnRotationModeChanged(TEnumAsByte<EALS_RotationMode> NewRotationMode);
	void OnStanceChanged(TEnumAsByte<EALS_Stance> NewStance);
	void OnMovementActionChanged(TEnumAsByte<EALS_MovementAction> NewMovementAction);
	void OnMovementStateChanged(TEnumAsByte<EALS_MovementState> NewMovementState);
	void OnCharacterMovementModeChanged(TEnumAsByte<EMovementMode> PrevMovementMode, TEnumAsByte<EMovementMode> NewMovementMode, unsigned char PrevCustomMode, unsigned char NewCustomMode);
	void On_Begin_Play();
	float GetAnimCurveValue(const struct FName& CurveName);
	TEnumAsByte<EDrawDebugTrace> GetTraceDebugType(TEnumAsByte<EDrawDebugTrace> ShowTraceType);
	void SetActorLocationDuringRagdoll();
	void RagdollUpdate();
	void RagdollEnd();
	void RagdollStart();
	struct FVector CalculateAcceleration();
	struct FVector GetCapsuleLocationFromBase(const struct FVector& BaseLocation, float ZOffset);
	struct FVector GetCalpsuleBaseLocation(float ZOffset);
	void RightVector(struct FVector* ForwardVector, struct FVector* RightVector);
	struct FMantle_Asset GetMantleAsset(TEnumAsByte<EMantleType> MantleType);
	void CapsuleHasRoomCheck(class UCapsuleComponent* Capsule, const struct FVector& TargetLocation, float HeightOffset, float RadiusOffset, TEnumAsByte<EDrawDebugTrace> DebugType, bool* HasRoom);
	void MantleUpdate(float BlendIn);
	void MantleEnd();
	void MantleStart(float MantleHeight, const struct FALS_ComponentAndTransform& MantleLedgeWS, TEnumAsByte<EMantleType> MantleType);
	void DrawDebugShapes();
	void FixDiagonalGamepadValues(float Y_in, float X_in, float* Y_Out, float* X_Out);
	struct FVector GetPlayerMovementInput();
	void MantleCheck(const struct FMantle_TraceSettings& Trace_Settings, TEnumAsByte<EDrawDebugTrace> DebugType, bool* Vault);
	float CalculateGroundedRotationRate();
	bool SetActorLocationAndRotation_UpdateTarget_(const struct FVector& NewLocation, const struct FRotator& NewRotation, bool bSweep, bool bTeleport, struct FHitResult* SweepHitResult);
	void LimitRotation(float AimYawMin, float AimYawMax, float InterpSpeed);
	void AddToCharacterRotation(const struct FRotator& DeltaRotation);
	void CanSprint(bool* CanSprint);
	void GetActualGait(TEnumAsByte<EALS_Gait> AllowedGait, TEnumAsByte<EALS_Gait>* ActualGait);
	void GetAllowedGait(TEnumAsByte<EALS_Gait>* AllowedGait);
	void GetTargetMovementSettings(struct FMovementSettings* MovementSettings);
	void UpdateDynamicMovementSettings(TEnumAsByte<EALS_Gait> AllowedGait);
	void UpdateCharacterMovement();
	void SetMovementModel();
	void SmoothCharacterRotation(const struct FRotator& Target, float TargetInterpSpeed_Const_, float ActorInterpSpeed_Smooth_);
	void UpdateInAirRotation();
	void UpdateGroudedRotation();
	void CacheValues();
	void SetEssentialValues();
	void PlayerMovementInput(bool IsForwardAxis);
	void MantleTimeline__FinishedFunc();
	void MantleTimeline__UpdateFunc();
	void InpActEvt_JumpAction_K2Node_InputActionEvent_13(const struct FKey& Key);
	void InpActEvt_JumpAction_K2Node_InputActionEvent_12(const struct FKey& Key);
	void InpActEvt_WalkAction_K2Node_InputActionEvent_11(const struct FKey& Key);
	void InpActEvt_SelectRotationMode_1_K2Node_InputActionEvent_10(const struct FKey& Key);
	void InpActEvt_SelectRotationMode_2_K2Node_InputActionEvent_9(const struct FKey& Key);
	void InpActEvt_AimAction_K2Node_InputActionEvent_8(const struct FKey& Key);
	void InpActEvt_AimAction_K2Node_InputActionEvent_7(const struct FKey& Key);
	void InpActEvt_StanceAction_K2Node_InputActionEvent_6(const struct FKey& Key);
	void InpActEvt_CameraAction_K2Node_InputActionEvent_5(const struct FKey& Key);
	void InpActEvt_CameraAction_K2Node_InputActionEvent_4(const struct FKey& Key);
	void InpActEvt_SprintAction_K2Node_InputActionEvent_3(const struct FKey& Key);
	void InpActEvt_SprintAction_K2Node_InputActionEvent_2(const struct FKey& Key);
	void InpActEvt_RagdollAction_K2Node_InputActionEvent_1(const struct FKey& Key);
	void Backwards_K2Node_InputAxisEvent_1(float AxisValue);
	void Left_K2Node_InputAxisEvent_2(float AxisValue);
	void Down_K2Node_InputAxisEvent_3(float AxisValue);
	void Right_K2Node_InputAxisEvent_4(float AxisValue);
	void ReceiveTick(float DeltaSeconds);
	void ReceiveBeginPlay();
	void K2_OnStartCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust);
	void K2_OnEndCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust);
	void K2_OnMovementModeChanged(TEnumAsByte<EMovementMode> PrevMovementMode, TEnumAsByte<EMovementMode> NewMovementMode, unsigned char PrevCustomMode, unsigned char NewCustomMode);
	void OnJumped();
	void OnLanded(const struct FHitResult& hit);
	void Breakfall_Event();
	void Roll_Event();
	void BPI_Set_MovementState(TEnumAsByte<EALS_MovementState> NewMovementState);
	void BPI_Set_MovementAction(TEnumAsByte<EALS_MovementAction> NewMovementAction);
	void BPI_Set_RotationMode(TEnumAsByte<EALS_RotationMode> NewRotationMode);
	void BPI_Set_Gait(TEnumAsByte<EALS_Gait> NewGait);
	void BPI_Set_ViewMode(TEnumAsByte<EALS_ViewMode> NewViewMode);
	void BPI_Set_OverlayState(TEnumAsByte<EALS_OverlayState> NewOverlayState);
	void ExecuteUbergraph_ALS_Base_CharacterBP(int EntryPoint);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
