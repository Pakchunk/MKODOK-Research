#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_CameraParameters
struct AALS_Base_CharacterBP_C_BPI_Get_CameraParameters_Params
{
	float                                              TP_FOV;                                                    // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              FP_FOV;                                                    // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                               RightShoulder;                                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_3P_TraceParams
struct AALS_Base_CharacterBP_C_BPI_Get_3P_TraceParams_Params
{
	struct FVector                                     TraceOrigin;                                               // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              TraceRadius;                                               // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<ETraceTypeQuery>                       TraceChannel;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_3P_PivotTarget
struct AALS_Base_CharacterBP_C_BPI_Get_3P_PivotTarget_Params
{
	struct FTransform                                  ReturnValue;                                               // (Parm, OutParm, ReturnParm, IsPlainOldData, NoDestructor)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_FP_CameraTarget
struct AALS_Base_CharacterBP_C_BPI_Get_FP_CameraTarget_Params
{
	struct FVector                                     ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_EssentialValues
struct AALS_Base_CharacterBP_C_BPI_Get_EssentialValues_Params
{
	struct FVector                                     Velocity;                                                  // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                                     Acceleration;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                                     MovementInput;                                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                               IsMoving;                                                  // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                               HasMovementInput;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	float                                              Speed;                                                     // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              MovementInputAmount;                                       // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FRotator                                    AimingRotation;                                            // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	float                                              AimYawRate;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_CurrentStates
struct AALS_Base_CharacterBP_C_BPI_Get_CurrentStates_Params
{
	TEnumAsByte<EMovementMode>                         PawnMovementMode;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_MovementState>                    MovementState;                                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_MovementState>                    PrevMovementState;                                         // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_MovementAction>                   MovementAction;                                            // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_RotationMode>                     RotationMode;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_Gait>                             ActualGait;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_Stance>                           ActualStance;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_ViewMode>                         ViewMode;                                                  // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_OverlayState>                     OverlayState;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetGetUpAnimation
struct AALS_Base_CharacterBP_C_GetGetUpAnimation_Params
{
	bool                                               RagdollFaceUp;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	class UAnimMontage*                                ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetRollAnimation
struct AALS_Base_CharacterBP_C_GetRollAnimation_Params
{
	class UAnimMontage*                                ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetMappedSpeed
struct AALS_Base_CharacterBP_C_GetMappedSpeed_Params
{
	float                                              ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CanUpdateMovingRotation
struct AALS_Base_CharacterBP_C_CanUpdateMovingRotation_Params
{
	bool                                               ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnOverlayStateChanged
struct AALS_Base_CharacterBP_C_OnOverlayStateChanged_Params
{
	TEnumAsByte<EALS_OverlayState>                     NewOverlayState;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnViewModeChanged
struct AALS_Base_CharacterBP_C_OnViewModeChanged_Params
{
	TEnumAsByte<EALS_ViewMode>                         NewViewMode;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnGaitChanged
struct AALS_Base_CharacterBP_C_OnGaitChanged_Params
{
	TEnumAsByte<EALS_Gait>                             NewActualGait;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnRotationModeChanged
struct AALS_Base_CharacterBP_C_OnRotationModeChanged_Params
{
	TEnumAsByte<EALS_RotationMode>                     NewRotationMode;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnStanceChanged
struct AALS_Base_CharacterBP_C_OnStanceChanged_Params
{
	TEnumAsByte<EALS_Stance>                           NewStance;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnMovementActionChanged
struct AALS_Base_CharacterBP_C_OnMovementActionChanged_Params
{
	TEnumAsByte<EALS_MovementAction>                   NewMovementAction;                                         // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnMovementStateChanged
struct AALS_Base_CharacterBP_C_OnMovementStateChanged_Params
{
	TEnumAsByte<EALS_MovementState>                    NewMovementState;                                          // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnCharacterMovementModeChanged
struct AALS_Base_CharacterBP_C_OnCharacterMovementModeChanged_Params
{
	TEnumAsByte<EMovementMode>                         PrevMovementMode;                                          // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EMovementMode>                         NewMovementMode;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	unsigned char                                      PrevCustomMode;                                            // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	unsigned char                                      NewCustomMode;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.On Begin Play
struct AALS_Base_CharacterBP_C_On_Begin_Play_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetAnimCurveValue
struct AALS_Base_CharacterBP_C_GetAnimCurveValue_Params
{
	struct FName                                       CurveName;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetTraceDebugType
struct AALS_Base_CharacterBP_C_GetTraceDebugType_Params
{
	TEnumAsByte<EDrawDebugTrace>                       ShowTraceType;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EDrawDebugTrace>                       ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SetActorLocationDuringRagdoll
struct AALS_Base_CharacterBP_C_SetActorLocationDuringRagdoll_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.RagdollUpdate
struct AALS_Base_CharacterBP_C_RagdollUpdate_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.RagdollEnd
struct AALS_Base_CharacterBP_C_RagdollEnd_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.RagdollStart
struct AALS_Base_CharacterBP_C_RagdollStart_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CalculateAcceleration
struct AALS_Base_CharacterBP_C_CalculateAcceleration_Params
{
	struct FVector                                     ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetCapsuleLocationFromBase
struct AALS_Base_CharacterBP_C_GetCapsuleLocationFromBase_Params
{
	struct FVector                                     BaseLocation;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              ZOffset;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                                     ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetCalpsuleBaseLocation
struct AALS_Base_CharacterBP_C_GetCalpsuleBaseLocation_Params
{
	float                                              ZOffset;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                                     ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.RightVector
struct AALS_Base_CharacterBP_C_RightVector_Params
{
	struct FVector                                     ForwardVector;                                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                                     RightVector;                                               // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetMantleAsset
struct AALS_Base_CharacterBP_C_GetMantleAsset_Params
{
	TEnumAsByte<EMantleType>                           MantleType;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FMantle_Asset                               ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CapsuleHasRoomCheck
struct AALS_Base_CharacterBP_C_CapsuleHasRoomCheck_Params
{
	class UCapsuleComponent*                           Capsule;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                                     TargetLocation;                                            // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              HeightOffset;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              RadiusOffset;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EDrawDebugTrace>                       DebugType;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                               HasRoom;                                                   // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleUpdate
struct AALS_Base_CharacterBP_C_MantleUpdate_Params
{
	float                                              BlendIn;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleEnd
struct AALS_Base_CharacterBP_C_MantleEnd_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleStart
struct AALS_Base_CharacterBP_C_MantleStart_Params
{
	float                                              MantleHeight;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FALS_ComponentAndTransform                  MantleLedgeWS;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, IsPlainOldData, NoDestructor, ContainsInstancedReference, HasGetValueTypeHash)
	TEnumAsByte<EMantleType>                           MantleType;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.DrawDebugShapes
struct AALS_Base_CharacterBP_C_DrawDebugShapes_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.FixDiagonalGamepadValues
struct AALS_Base_CharacterBP_C_FixDiagonalGamepadValues_Params
{
	float                                              Y_in;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              X_in;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              Y_Out;                                                     // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              X_Out;                                                     // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetPlayerMovementInput
struct AALS_Base_CharacterBP_C_GetPlayerMovementInput_Params
{
	struct FVector                                     ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleCheck
struct AALS_Base_CharacterBP_C_MantleCheck_Params
{
	struct FMantle_TraceSettings                       Trace_Settings;                                            // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EDrawDebugTrace>                       DebugType;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                               Vault;                                                     // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CalculateGroundedRotationRate
struct AALS_Base_CharacterBP_C_CalculateGroundedRotationRate_Params
{
	float                                              ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SetActorLocationAndRotation(UpdateTarget)
struct AALS_Base_CharacterBP_C_SetActorLocationAndRotation_UpdateTarget__Params
{
	struct FVector                                     NewLocation;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FRotator                                    NewRotation;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                               bSweep;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                               bTeleport;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	struct FHitResult                                  SweepHitResult;                                            // (Parm, OutParm, IsPlainOldData, NoDestructor, ContainsInstancedReference)
	bool                                               ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.LimitRotation
struct AALS_Base_CharacterBP_C_LimitRotation_Params
{
	float                                              AimYawMin;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              AimYawMax;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              InterpSpeed;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.AddToCharacterRotation
struct AALS_Base_CharacterBP_C_AddToCharacterRotation_Params
{
	struct FRotator                                    DeltaRotation;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CanSprint
struct AALS_Base_CharacterBP_C_CanSprint_Params
{
	bool                                               CanSprint;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetActualGait
struct AALS_Base_CharacterBP_C_GetActualGait_Params
{
	TEnumAsByte<EALS_Gait>                             AllowedGait;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EALS_Gait>                             ActualGait;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetAllowedGait
struct AALS_Base_CharacterBP_C_GetAllowedGait_Params
{
	TEnumAsByte<EALS_Gait>                             AllowedGait;                                               // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetTargetMovementSettings
struct AALS_Base_CharacterBP_C_GetTargetMovementSettings_Params
{
	struct FMovementSettings                           MovementSettings;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.UpdateDynamicMovementSettings
struct AALS_Base_CharacterBP_C_UpdateDynamicMovementSettings_Params
{
	TEnumAsByte<EALS_Gait>                             AllowedGait;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.UpdateCharacterMovement
struct AALS_Base_CharacterBP_C_UpdateCharacterMovement_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SetMovementModel
struct AALS_Base_CharacterBP_C_SetMovementModel_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SmoothCharacterRotation
struct AALS_Base_CharacterBP_C_SmoothCharacterRotation_Params
{
	struct FRotator                                    Target;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	float                                              TargetInterpSpeed_Const_;                                  // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              ActorInterpSpeed_Smooth_;                                  // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.UpdateInAirRotation
struct AALS_Base_CharacterBP_C_UpdateInAirRotation_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.UpdateGroudedRotation
struct AALS_Base_CharacterBP_C_UpdateGroudedRotation_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CacheValues
struct AALS_Base_CharacterBP_C_CacheValues_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SetEssentialValues
struct AALS_Base_CharacterBP_C_SetEssentialValues_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.PlayerMovementInput
struct AALS_Base_CharacterBP_C_PlayerMovementInput_Params
{
	bool                                               IsForwardAxis;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleTimeline__FinishedFunc
struct AALS_Base_CharacterBP_C_MantleTimeline__FinishedFunc_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleTimeline__UpdateFunc
struct AALS_Base_CharacterBP_C_MantleTimeline__UpdateFunc_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_JumpAction_K2Node_InputActionEvent_13
struct AALS_Base_CharacterBP_C_InpActEvt_JumpAction_K2Node_InputActionEvent_13_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_JumpAction_K2Node_InputActionEvent_12
struct AALS_Base_CharacterBP_C_InpActEvt_JumpAction_K2Node_InputActionEvent_12_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_WalkAction_K2Node_InputActionEvent_11
struct AALS_Base_CharacterBP_C_InpActEvt_WalkAction_K2Node_InputActionEvent_11_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_SelectRotationMode_1_K2Node_InputActionEvent_10
struct AALS_Base_CharacterBP_C_InpActEvt_SelectRotationMode_1_K2Node_InputActionEvent_10_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_SelectRotationMode_2_K2Node_InputActionEvent_9
struct AALS_Base_CharacterBP_C_InpActEvt_SelectRotationMode_2_K2Node_InputActionEvent_9_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_AimAction_K2Node_InputActionEvent_8
struct AALS_Base_CharacterBP_C_InpActEvt_AimAction_K2Node_InputActionEvent_8_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_AimAction_K2Node_InputActionEvent_7
struct AALS_Base_CharacterBP_C_InpActEvt_AimAction_K2Node_InputActionEvent_7_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_StanceAction_K2Node_InputActionEvent_6
struct AALS_Base_CharacterBP_C_InpActEvt_StanceAction_K2Node_InputActionEvent_6_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_CameraAction_K2Node_InputActionEvent_5
struct AALS_Base_CharacterBP_C_InpActEvt_CameraAction_K2Node_InputActionEvent_5_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_CameraAction_K2Node_InputActionEvent_4
struct AALS_Base_CharacterBP_C_InpActEvt_CameraAction_K2Node_InputActionEvent_4_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_SprintAction_K2Node_InputActionEvent_3
struct AALS_Base_CharacterBP_C_InpActEvt_SprintAction_K2Node_InputActionEvent_3_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_SprintAction_K2Node_InputActionEvent_2
struct AALS_Base_CharacterBP_C_InpActEvt_SprintAction_K2Node_InputActionEvent_2_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_RagdollAction_K2Node_InputActionEvent_1
struct AALS_Base_CharacterBP_C_InpActEvt_RagdollAction_K2Node_InputActionEvent_1_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Backwards_K2Node_InputAxisEvent_1
struct AALS_Base_CharacterBP_C_Backwards_K2Node_InputAxisEvent_1_Params
{
	float                                              AxisValue;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Left_K2Node_InputAxisEvent_2
struct AALS_Base_CharacterBP_C_Left_K2Node_InputAxisEvent_2_Params
{
	float                                              AxisValue;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Down_K2Node_InputAxisEvent_3
struct AALS_Base_CharacterBP_C_Down_K2Node_InputAxisEvent_3_Params
{
	float                                              AxisValue;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Right_K2Node_InputAxisEvent_4
struct AALS_Base_CharacterBP_C_Right_K2Node_InputAxisEvent_4_Params
{
	float                                              AxisValue;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.ReceiveTick
struct AALS_Base_CharacterBP_C_ReceiveTick_Params
{
	float                                              DeltaSeconds;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.ReceiveBeginPlay
struct AALS_Base_CharacterBP_C_ReceiveBeginPlay_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.K2_OnStartCrouch
struct AALS_Base_CharacterBP_C_K2_OnStartCrouch_Params
{
	float                                              HalfHeightAdjust;                                          // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              ScaledHalfHeightAdjust;                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.K2_OnEndCrouch
struct AALS_Base_CharacterBP_C_K2_OnEndCrouch_Params
{
	float                                              HalfHeightAdjust;                                          // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              ScaledHalfHeightAdjust;                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.K2_OnMovementModeChanged
struct AALS_Base_CharacterBP_C_K2_OnMovementModeChanged_Params
{
	TEnumAsByte<EMovementMode>                         PrevMovementMode;                                          // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EMovementMode>                         NewMovementMode;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	unsigned char                                      PrevCustomMode;                                            // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	unsigned char                                      NewCustomMode;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnJumped
struct AALS_Base_CharacterBP_C_OnJumped_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnLanded
struct AALS_Base_CharacterBP_C_OnLanded_Params
{
	struct FHitResult                                  hit;                                                       // (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm, IsPlainOldData, NoDestructor, ContainsInstancedReference)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Breakfall Event
struct AALS_Base_CharacterBP_C_Breakfall_Event_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Roll Event
struct AALS_Base_CharacterBP_C_Roll_Event_Params
{
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_MovementState
struct AALS_Base_CharacterBP_C_BPI_Set_MovementState_Params
{
	TEnumAsByte<EALS_MovementState>                    NewMovementState;                                          // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_MovementAction
struct AALS_Base_CharacterBP_C_BPI_Set_MovementAction_Params
{
	TEnumAsByte<EALS_MovementAction>                   NewMovementAction;                                         // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_RotationMode
struct AALS_Base_CharacterBP_C_BPI_Set_RotationMode_Params
{
	TEnumAsByte<EALS_RotationMode>                     NewRotationMode;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_Gait
struct AALS_Base_CharacterBP_C_BPI_Set_Gait_Params
{
	TEnumAsByte<EALS_Gait>                             NewGait;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_ViewMode
struct AALS_Base_CharacterBP_C_BPI_Set_ViewMode_Params
{
	TEnumAsByte<EALS_ViewMode>                         NewViewMode;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_OverlayState
struct AALS_Base_CharacterBP_C_BPI_Set_OverlayState_Params
{
	TEnumAsByte<EALS_OverlayState>                     NewOverlayState;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.ExecuteUbergraph_ALS_Base_CharacterBP
struct AALS_Base_CharacterBP_C_ExecuteUbergraph_ALS_Base_CharacterBP_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
