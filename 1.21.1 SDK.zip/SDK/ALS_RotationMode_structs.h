#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// UserDefinedEnum ALS_RotationMode.ALS_RotationMode
enum class EALS_RotationMode : uint8_t
{
	ALS_RotationMode__NewEnumerator0 = 0,
	ALS_RotationMode__NewEnumerator1 = 1,
	ALS_RotationMode__NewEnumerator3 = 2,
	ALS_RotationMode__ALS_MAX      = 3,

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
