#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// UserDefinedEnum ALS_OverlayState.ALS_OverlayState
enum class EALS_OverlayState : uint8_t
{
	ALS_OverlayState__NewEnumerator0 = 0,
	ALS_OverlayState__NewEnumerator12 = 1,
	ALS_OverlayState__NewEnumerator13 = 2,
	ALS_OverlayState__NewEnumerator14 = 3,
	ALS_OverlayState__NewEnumerator15 = 4,
	ALS_OverlayState__NewEnumerator1 = 5,
	ALS_OverlayState__NewEnumerator5 = 6,
	ALS_OverlayState__NewEnumerator10 = 7,
	ALS_OverlayState__NewEnumerator6 = 8,
	ALS_OverlayState__NewEnumerator7 = 9,
	ALS_OverlayState__NewEnumerator8 = 10,
	ALS_OverlayState__NewEnumerator9 = 11,
	ALS_OverlayState__NewEnumerator11 = 12,
	ALS_OverlayState__ALS_MAX      = 13,

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
