#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.GetDebugTraceType
struct AALS_PlayerCameraManager_C_GetDebugTraceType_Params
{
	TEnumAsByte<EDrawDebugTrace>                       ShowTraceType;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TEnumAsByte<EDrawDebugTrace>                       DebugTypu;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.Get_CameraBehaviorParam
struct AALS_PlayerCameraManager_C_Get_CameraBehaviorParam_Params
{
	struct FName                                       CurveName;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                              ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.CalculateAxisIndependentLag
struct AALS_PlayerCameraManager_C_CalculateAxisIndependentLag_Params
{
	struct FVector                                     CurrentLocation;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                                     TargetLocation;                                            // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FRotator                                    CameraRotation;                                            // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	struct FVector                                     LagSpeeds;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                                     ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.CustomCameraBehavior
struct AALS_PlayerCameraManager_C_CustomCameraBehavior_Params
{
	struct FVector                                     Location;                                                  // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FRotator                                    Rotation;                                                  // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	float                                              FOV;                                                       // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.BlueprintUpdateCamera
struct AALS_PlayerCameraManager_C_BlueprintUpdateCamera_Params
{
	class AActor*                                      CameraTarget;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                                     NewCameraLocation;                                         // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FRotator                                    NewCameraRotation;                                         // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	float                                              NewCameraFOV;                                              // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                               ReturnValue;                                               // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor)
};

// Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.OnPossess
struct AALS_PlayerCameraManager_C_OnPossess_Params
{
	class APawn*                                       NewPawn;                                                   // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.ExecuteUbergraph_ALS_PlayerCameraManager
struct AALS_PlayerCameraManager_C_ExecuteUbergraph_ALS_PlayerCameraManager_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
