// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function DEATH.DEATH_C.Construct
// (BlueprintCosmetic, Event, Public, BlueprintEvent)
void UDEATH_C::Construct()
{
	static auto fn = UObject::FindObject<UFunction>("Function DEATH.DEATH_C.Construct");

	UDEATH_C_Construct_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function DEATH.DEATH_C.BndEvt__Button_301_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
// (BlueprintEvent)
void UDEATH_C::BndEvt__Button_301_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature()
{
	static auto fn = UObject::FindObject<UFunction>("Function DEATH.DEATH_C.BndEvt__Button_301_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature");

	UDEATH_C_BndEvt__Button_301_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function DEATH.DEATH_C.ExecuteUbergraph_DEATH
// (Final)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UDEATH_C::ExecuteUbergraph_DEATH(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function DEATH.DEATH_C.ExecuteUbergraph_DEATH");

	UDEATH_C_ExecuteUbergraph_DEATH_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
