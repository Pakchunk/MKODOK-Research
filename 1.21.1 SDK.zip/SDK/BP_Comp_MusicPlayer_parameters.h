#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnPauseSong
struct UBP_Comp_MusicPlayer_C_fnPauseSong_Params
{
};

// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnPlayPrevious
struct UBP_Comp_MusicPlayer_C_fnPlayPrevious_Params
{
};

// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnPlayNext
struct UBP_Comp_MusicPlayer_C_fnPlayNext_Params
{
};

// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnCreateHUD
struct UBP_Comp_MusicPlayer_C_fnCreateHUD_Params
{
};

// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnPlaySong
struct UBP_Comp_MusicPlayer_C_fnPlaySong_Params
{
};

// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.EventStartMusic
struct UBP_Comp_MusicPlayer_C_EventStartMusic_Params
{
};

// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.EventStopMusic
struct UBP_Comp_MusicPlayer_C_EventStopMusic_Params
{
};

// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.EventCheckMusicIsPlaying
struct UBP_Comp_MusicPlayer_C_EventCheckMusicIsPlaying_Params
{
};

// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.ExecuteUbergraph_BP_Comp_MusicPlayer
struct UBP_Comp_MusicPlayer_C_ExecuteUbergraph_BP_Comp_MusicPlayer_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
