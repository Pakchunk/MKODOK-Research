#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// UserDefinedEnum ALS_MovementAction.ALS_MovementAction
enum class EALS_MovementAction : uint8_t
{
	ALS_MovementAction__NewEnumerator4 = 0,
	ALS_MovementAction__NewEnumerator0 = 1,
	ALS_MovementAction__NewEnumerator1 = 2,
	ALS_MovementAction__NewEnumerator2 = 3,
	ALS_MovementAction__NewEnumerator3 = 4,
	ALS_MovementAction__NewEnumerator5 = 5,
	ALS_MovementAction__ALS_MAX    = 6,

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
