// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function ALS_Animation_BPI.ALS_Animation_BPI_C.BPI_SetOverlayOverrideState
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// int                            OverlayOverrideState           (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UALS_Animation_BPI_C::BPI_SetOverlayOverrideState(int OverlayOverrideState)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Animation_BPI.ALS_Animation_BPI_C.BPI_SetOverlayOverrideState");

	UALS_Animation_BPI_C_BPI_SetOverlayOverrideState_Params params;
	params.OverlayOverrideState = OverlayOverrideState;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Animation_BPI.ALS_Animation_BPI_C.BPI_SetGroundedEntryState
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EGroundedEntryState> GroundedEntryState             (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UALS_Animation_BPI_C::BPI_SetGroundedEntryState(TEnumAsByte<EGroundedEntryState> GroundedEntryState)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Animation_BPI.ALS_Animation_BPI_C.BPI_SetGroundedEntryState");

	UALS_Animation_BPI_C_BPI_SetGroundedEntryState_Params params;
	params.GroundedEntryState = GroundedEntryState;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Animation_BPI.ALS_Animation_BPI_C.BPI_Jumped
// (Public, BlueprintCallable, BlueprintEvent)
void UALS_Animation_BPI_C::BPI_Jumped()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Animation_BPI.ALS_Animation_BPI_C.BPI_Jumped");

	UALS_Animation_BPI_C_BPI_Jumped_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
