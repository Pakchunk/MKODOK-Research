#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// UserDefinedEnum HipsDirection.HipsDirection
enum class EHipsDirection : uint8_t
{
	HipsDirection__NewEnumerator0  = 0,
	HipsDirection__NewEnumerator1  = 1,
	HipsDirection__NewEnumerator2  = 2,
	HipsDirection__NewEnumerator3  = 3,
	HipsDirection__NewEnumerator4  = 4,
	HipsDirection__NewEnumerator5  = 5,
	HipsDirection__HipsDirection_MAX = 6,

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
