// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_CameraParameters
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
// float                          TP_FOV                         (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          FP_FOV                         (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                           RightShoulder                  (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
void AALS_Base_CharacterBP_C::BPI_Get_CameraParameters(float* TP_FOV, float* FP_FOV, bool* RightShoulder)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_CameraParameters");

	AALS_Base_CharacterBP_C_BPI_Get_CameraParameters_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (TP_FOV != nullptr)
		*TP_FOV = params.TP_FOV;
	if (FP_FOV != nullptr)
		*FP_FOV = params.FP_FOV;
	if (RightShoulder != nullptr)
		*RightShoulder = params.RightShoulder;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_3P_TraceParams
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FVector                 TraceOrigin                    (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          TraceRadius                    (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<ETraceTypeQuery>   TraceChannel                   (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::BPI_Get_3P_TraceParams(struct FVector* TraceOrigin, float* TraceRadius, TEnumAsByte<ETraceTypeQuery>* TraceChannel)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_3P_TraceParams");

	AALS_Base_CharacterBP_C_BPI_Get_3P_TraceParams_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (TraceOrigin != nullptr)
		*TraceOrigin = params.TraceOrigin;
	if (TraceRadius != nullptr)
		*TraceRadius = params.TraceRadius;
	if (TraceChannel != nullptr)
		*TraceChannel = params.TraceChannel;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_3P_PivotTarget
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FTransform              ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData, NoDestructor)
struct FTransform AALS_Base_CharacterBP_C::BPI_Get_3P_PivotTarget()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_3P_PivotTarget");

	AALS_Base_CharacterBP_C_BPI_Get_3P_PivotTarget_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_FP_CameraTarget
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FVector                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
struct FVector AALS_Base_CharacterBP_C::BPI_Get_FP_CameraTarget()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_FP_CameraTarget");

	AALS_Base_CharacterBP_C_BPI_Get_FP_CameraTarget_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_EssentialValues
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FVector                 Velocity                       (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FVector                 Acceleration                   (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FVector                 MovementInput                  (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                           IsMoving                       (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                           HasMovementInput               (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
// float                          Speed                          (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          MovementInputAmount            (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FRotator                AimingRotation                 (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
// float                          AimYawRate                     (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::BPI_Get_EssentialValues(struct FVector* Velocity, struct FVector* Acceleration, struct FVector* MovementInput, bool* IsMoving, bool* HasMovementInput, float* Speed, float* MovementInputAmount, struct FRotator* AimingRotation, float* AimYawRate)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_EssentialValues");

	AALS_Base_CharacterBP_C_BPI_Get_EssentialValues_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (Velocity != nullptr)
		*Velocity = params.Velocity;
	if (Acceleration != nullptr)
		*Acceleration = params.Acceleration;
	if (MovementInput != nullptr)
		*MovementInput = params.MovementInput;
	if (IsMoving != nullptr)
		*IsMoving = params.IsMoving;
	if (HasMovementInput != nullptr)
		*HasMovementInput = params.HasMovementInput;
	if (Speed != nullptr)
		*Speed = params.Speed;
	if (MovementInputAmount != nullptr)
		*MovementInputAmount = params.MovementInputAmount;
	if (AimingRotation != nullptr)
		*AimingRotation = params.AimingRotation;
	if (AimYawRate != nullptr)
		*AimYawRate = params.AimYawRate;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_CurrentStates
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EMovementMode>     PawnMovementMode               (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_MovementState> MovementState                  (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_MovementState> PrevMovementState              (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_MovementAction> MovementAction                 (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_RotationMode> RotationMode                   (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_Gait>         ActualGait                     (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_Stance>       ActualStance                   (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_ViewMode>     ViewMode                       (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_OverlayState> OverlayState                   (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::BPI_Get_CurrentStates(TEnumAsByte<EMovementMode>* PawnMovementMode, TEnumAsByte<EALS_MovementState>* MovementState, TEnumAsByte<EALS_MovementState>* PrevMovementState, TEnumAsByte<EALS_MovementAction>* MovementAction, TEnumAsByte<EALS_RotationMode>* RotationMode, TEnumAsByte<EALS_Gait>* ActualGait, TEnumAsByte<EALS_Stance>* ActualStance, TEnumAsByte<EALS_ViewMode>* ViewMode, TEnumAsByte<EALS_OverlayState>* OverlayState)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Get_CurrentStates");

	AALS_Base_CharacterBP_C_BPI_Get_CurrentStates_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (PawnMovementMode != nullptr)
		*PawnMovementMode = params.PawnMovementMode;
	if (MovementState != nullptr)
		*MovementState = params.MovementState;
	if (PrevMovementState != nullptr)
		*PrevMovementState = params.PrevMovementState;
	if (MovementAction != nullptr)
		*MovementAction = params.MovementAction;
	if (RotationMode != nullptr)
		*RotationMode = params.RotationMode;
	if (ActualGait != nullptr)
		*ActualGait = params.ActualGait;
	if (ActualStance != nullptr)
		*ActualStance = params.ActualStance;
	if (ViewMode != nullptr)
		*ViewMode = params.ViewMode;
	if (OverlayState != nullptr)
		*OverlayState = params.OverlayState;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetGetUpAnimation
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// bool                           RagdollFaceUp                  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
// class UAnimMontage*            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
class UAnimMontage* AALS_Base_CharacterBP_C::GetGetUpAnimation(bool RagdollFaceUp)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetGetUpAnimation");

	AALS_Base_CharacterBP_C_GetGetUpAnimation_Params params;
	params.RagdollFaceUp = RagdollFaceUp;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetRollAnimation
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// class UAnimMontage*            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
class UAnimMontage* AALS_Base_CharacterBP_C::GetRollAnimation()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetRollAnimation");

	AALS_Base_CharacterBP_C_GetRollAnimation_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetMappedSpeed
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
float AALS_Base_CharacterBP_C::GetMappedSpeed()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetMappedSpeed");

	AALS_Base_CharacterBP_C_GetMappedSpeed_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CanUpdateMovingRotation
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor)
bool AALS_Base_CharacterBP_C::CanUpdateMovingRotation()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CanUpdateMovingRotation");

	AALS_Base_CharacterBP_C_CanUpdateMovingRotation_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnOverlayStateChanged
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_OverlayState> NewOverlayState                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::OnOverlayStateChanged(TEnumAsByte<EALS_OverlayState> NewOverlayState)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnOverlayStateChanged");

	AALS_Base_CharacterBP_C_OnOverlayStateChanged_Params params;
	params.NewOverlayState = NewOverlayState;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnViewModeChanged
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_ViewMode>     NewViewMode                    (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::OnViewModeChanged(TEnumAsByte<EALS_ViewMode> NewViewMode)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnViewModeChanged");

	AALS_Base_CharacterBP_C_OnViewModeChanged_Params params;
	params.NewViewMode = NewViewMode;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnGaitChanged
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_Gait>         NewActualGait                  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::OnGaitChanged(TEnumAsByte<EALS_Gait> NewActualGait)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnGaitChanged");

	AALS_Base_CharacterBP_C_OnGaitChanged_Params params;
	params.NewActualGait = NewActualGait;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnRotationModeChanged
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_RotationMode> NewRotationMode                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::OnRotationModeChanged(TEnumAsByte<EALS_RotationMode> NewRotationMode)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnRotationModeChanged");

	AALS_Base_CharacterBP_C_OnRotationModeChanged_Params params;
	params.NewRotationMode = NewRotationMode;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnStanceChanged
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_Stance>       NewStance                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::OnStanceChanged(TEnumAsByte<EALS_Stance> NewStance)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnStanceChanged");

	AALS_Base_CharacterBP_C_OnStanceChanged_Params params;
	params.NewStance = NewStance;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnMovementActionChanged
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_MovementAction> NewMovementAction              (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::OnMovementActionChanged(TEnumAsByte<EALS_MovementAction> NewMovementAction)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnMovementActionChanged");

	AALS_Base_CharacterBP_C_OnMovementActionChanged_Params params;
	params.NewMovementAction = NewMovementAction;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnMovementStateChanged
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_MovementState> NewMovementState               (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::OnMovementStateChanged(TEnumAsByte<EALS_MovementState> NewMovementState)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnMovementStateChanged");

	AALS_Base_CharacterBP_C_OnMovementStateChanged_Params params;
	params.NewMovementState = NewMovementState;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnCharacterMovementModeChanged
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EMovementMode>     PrevMovementMode               (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EMovementMode>     NewMovementMode                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// unsigned char                  PrevCustomMode                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// unsigned char                  NewCustomMode                  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::OnCharacterMovementModeChanged(TEnumAsByte<EMovementMode> PrevMovementMode, TEnumAsByte<EMovementMode> NewMovementMode, unsigned char PrevCustomMode, unsigned char NewCustomMode)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnCharacterMovementModeChanged");

	AALS_Base_CharacterBP_C_OnCharacterMovementModeChanged_Params params;
	params.PrevMovementMode = PrevMovementMode;
	params.NewMovementMode = NewMovementMode;
	params.PrevCustomMode = PrevCustomMode;
	params.NewCustomMode = NewCustomMode;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.On Begin Play
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::On_Begin_Play()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.On Begin Play");

	AALS_Base_CharacterBP_C_On_Begin_Play_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetAnimCurveValue
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FName                   CurveName                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
float AALS_Base_CharacterBP_C::GetAnimCurveValue(const struct FName& CurveName)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetAnimCurveValue");

	AALS_Base_CharacterBP_C_GetAnimCurveValue_Params params;
	params.CurveName = CurveName;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetTraceDebugType
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// TEnumAsByte<EDrawDebugTrace>   ShowTraceType                  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EDrawDebugTrace>   ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
TEnumAsByte<EDrawDebugTrace> AALS_Base_CharacterBP_C::GetTraceDebugType(TEnumAsByte<EDrawDebugTrace> ShowTraceType)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetTraceDebugType");

	AALS_Base_CharacterBP_C_GetTraceDebugType_Params params;
	params.ShowTraceType = ShowTraceType;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SetActorLocationDuringRagdoll
// (Public, HasDefaults, BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::SetActorLocationDuringRagdoll()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SetActorLocationDuringRagdoll");

	AALS_Base_CharacterBP_C_SetActorLocationDuringRagdoll_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.RagdollUpdate
// (Public, HasDefaults, BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::RagdollUpdate()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.RagdollUpdate");

	AALS_Base_CharacterBP_C_RagdollUpdate_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.RagdollEnd
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::RagdollEnd()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.RagdollEnd");

	AALS_Base_CharacterBP_C_RagdollEnd_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.RagdollStart
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::RagdollStart()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.RagdollStart");

	AALS_Base_CharacterBP_C_RagdollStart_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CalculateAcceleration
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FVector                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
struct FVector AALS_Base_CharacterBP_C::CalculateAcceleration()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CalculateAcceleration");

	AALS_Base_CharacterBP_C_CalculateAcceleration_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetCapsuleLocationFromBase
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FVector                 BaseLocation                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          ZOffset                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FVector                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
struct FVector AALS_Base_CharacterBP_C::GetCapsuleLocationFromBase(const struct FVector& BaseLocation, float ZOffset)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetCapsuleLocationFromBase");

	AALS_Base_CharacterBP_C_GetCapsuleLocationFromBase_Params params;
	params.BaseLocation = BaseLocation;
	params.ZOffset = ZOffset;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetCalpsuleBaseLocation
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// float                          ZOffset                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FVector                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
struct FVector AALS_Base_CharacterBP_C::GetCalpsuleBaseLocation(float ZOffset)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetCalpsuleBaseLocation");

	AALS_Base_CharacterBP_C_GetCalpsuleBaseLocation_Params params;
	params.ZOffset = ZOffset;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.RightVector
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FVector                 ForwardVector                  (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FVector                 RightVector                    (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::RightVector(struct FVector* ForwardVector, struct FVector* RightVector)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.RightVector");

	AALS_Base_CharacterBP_C_RightVector_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (ForwardVector != nullptr)
		*ForwardVector = params.ForwardVector;
	if (RightVector != nullptr)
		*RightVector = params.RightVector;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetMantleAsset
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// TEnumAsByte<EMantleType>       MantleType                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FMantle_Asset           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
struct FMantle_Asset AALS_Base_CharacterBP_C::GetMantleAsset(TEnumAsByte<EMantleType> MantleType)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetMantleAsset");

	AALS_Base_CharacterBP_C_GetMantleAsset_Params params;
	params.MantleType = MantleType;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CapsuleHasRoomCheck
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// class UCapsuleComponent*       Capsule                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FVector                 TargetLocation                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          HeightOffset                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          RadiusOffset                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EDrawDebugTrace>   DebugType                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                           HasRoom                        (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
void AALS_Base_CharacterBP_C::CapsuleHasRoomCheck(class UCapsuleComponent* Capsule, const struct FVector& TargetLocation, float HeightOffset, float RadiusOffset, TEnumAsByte<EDrawDebugTrace> DebugType, bool* HasRoom)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CapsuleHasRoomCheck");

	AALS_Base_CharacterBP_C_CapsuleHasRoomCheck_Params params;
	params.Capsule = Capsule;
	params.TargetLocation = TargetLocation;
	params.HeightOffset = HeightOffset;
	params.RadiusOffset = RadiusOffset;
	params.DebugType = DebugType;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (HasRoom != nullptr)
		*HasRoom = params.HasRoom;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleUpdate
// (Public, HasDefaults, BlueprintCallable, BlueprintEvent)
// Parameters:
// float                          BlendIn                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::MantleUpdate(float BlendIn)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleUpdate");

	AALS_Base_CharacterBP_C_MantleUpdate_Params params;
	params.BlendIn = BlendIn;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleEnd
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::MantleEnd()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleEnd");

	AALS_Base_CharacterBP_C_MantleEnd_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleStart
// (Public, HasDefaults, BlueprintCallable, BlueprintEvent)
// Parameters:
// float                          MantleHeight                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FALS_ComponentAndTransform MantleLedgeWS                  (BlueprintVisible, BlueprintReadOnly, Parm, IsPlainOldData, NoDestructor, ContainsInstancedReference, HasGetValueTypeHash)
// TEnumAsByte<EMantleType>       MantleType                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::MantleStart(float MantleHeight, const struct FALS_ComponentAndTransform& MantleLedgeWS, TEnumAsByte<EMantleType> MantleType)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleStart");

	AALS_Base_CharacterBP_C_MantleStart_Params params;
	params.MantleHeight = MantleHeight;
	params.MantleLedgeWS = MantleLedgeWS;
	params.MantleType = MantleType;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.DrawDebugShapes
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::DrawDebugShapes()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.DrawDebugShapes");

	AALS_Base_CharacterBP_C_DrawDebugShapes_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.FixDiagonalGamepadValues
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// float                          Y_in                           (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          X_in                           (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          Y_Out                          (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          X_Out                          (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::FixDiagonalGamepadValues(float Y_in, float X_in, float* Y_Out, float* X_Out)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.FixDiagonalGamepadValues");

	AALS_Base_CharacterBP_C_FixDiagonalGamepadValues_Params params;
	params.Y_in = Y_in;
	params.X_in = X_in;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (Y_Out != nullptr)
		*Y_Out = params.Y_Out;
	if (X_Out != nullptr)
		*X_Out = params.X_Out;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetPlayerMovementInput
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FVector                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
struct FVector AALS_Base_CharacterBP_C::GetPlayerMovementInput()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetPlayerMovementInput");

	AALS_Base_CharacterBP_C_GetPlayerMovementInput_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleCheck
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FMantle_TraceSettings   Trace_Settings                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EDrawDebugTrace>   DebugType                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                           Vault                          (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
void AALS_Base_CharacterBP_C::MantleCheck(const struct FMantle_TraceSettings& Trace_Settings, TEnumAsByte<EDrawDebugTrace> DebugType, bool* Vault)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleCheck");

	AALS_Base_CharacterBP_C_MantleCheck_Params params;
	params.Trace_Settings = Trace_Settings;
	params.DebugType = DebugType;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (Vault != nullptr)
		*Vault = params.Vault;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CalculateGroundedRotationRate
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
float AALS_Base_CharacterBP_C::CalculateGroundedRotationRate()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CalculateGroundedRotationRate");

	AALS_Base_CharacterBP_C_CalculateGroundedRotationRate_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SetActorLocationAndRotation(UpdateTarget)
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FVector                 NewLocation                    (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FRotator                NewRotation                    (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                           bSweep                         (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                           bTeleport                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
// struct FHitResult              SweepHitResult                 (Parm, OutParm, IsPlainOldData, NoDestructor, ContainsInstancedReference)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor)
bool AALS_Base_CharacterBP_C::SetActorLocationAndRotation_UpdateTarget_(const struct FVector& NewLocation, const struct FRotator& NewRotation, bool bSweep, bool bTeleport, struct FHitResult* SweepHitResult)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SetActorLocationAndRotation(UpdateTarget)");

	AALS_Base_CharacterBP_C_SetActorLocationAndRotation_UpdateTarget__Params params;
	params.NewLocation = NewLocation;
	params.NewRotation = NewRotation;
	params.bSweep = bSweep;
	params.bTeleport = bTeleport;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (SweepHitResult != nullptr)
		*SweepHitResult = params.SweepHitResult;


	return params.ReturnValue;
}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.LimitRotation
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// float                          AimYawMin                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          AimYawMax                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          InterpSpeed                    (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::LimitRotation(float AimYawMin, float AimYawMax, float InterpSpeed)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.LimitRotation");

	AALS_Base_CharacterBP_C_LimitRotation_Params params;
	params.AimYawMin = AimYawMin;
	params.AimYawMax = AimYawMax;
	params.InterpSpeed = InterpSpeed;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.AddToCharacterRotation
// (Public, HasDefaults, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FRotator                DeltaRotation                  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
void AALS_Base_CharacterBP_C::AddToCharacterRotation(const struct FRotator& DeltaRotation)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.AddToCharacterRotation");

	AALS_Base_CharacterBP_C_AddToCharacterRotation_Params params;
	params.DeltaRotation = DeltaRotation;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CanSprint
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// bool                           CanSprint                      (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
void AALS_Base_CharacterBP_C::CanSprint(bool* CanSprint)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CanSprint");

	AALS_Base_CharacterBP_C_CanSprint_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (CanSprint != nullptr)
		*CanSprint = params.CanSprint;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetActualGait
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// TEnumAsByte<EALS_Gait>         AllowedGait                    (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_Gait>         ActualGait                     (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::GetActualGait(TEnumAsByte<EALS_Gait> AllowedGait, TEnumAsByte<EALS_Gait>* ActualGait)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetActualGait");

	AALS_Base_CharacterBP_C_GetActualGait_Params params;
	params.AllowedGait = AllowedGait;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (ActualGait != nullptr)
		*ActualGait = params.ActualGait;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetAllowedGait
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// TEnumAsByte<EALS_Gait>         AllowedGait                    (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::GetAllowedGait(TEnumAsByte<EALS_Gait>* AllowedGait)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetAllowedGait");

	AALS_Base_CharacterBP_C_GetAllowedGait_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (AllowedGait != nullptr)
		*AllowedGait = params.AllowedGait;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetTargetMovementSettings
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FMovementSettings       MovementSettings               (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::GetTargetMovementSettings(struct FMovementSettings* MovementSettings)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.GetTargetMovementSettings");

	AALS_Base_CharacterBP_C_GetTargetMovementSettings_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (MovementSettings != nullptr)
		*MovementSettings = params.MovementSettings;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.UpdateDynamicMovementSettings
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_Gait>         AllowedGait                    (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::UpdateDynamicMovementSettings(TEnumAsByte<EALS_Gait> AllowedGait)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.UpdateDynamicMovementSettings");

	AALS_Base_CharacterBP_C_UpdateDynamicMovementSettings_Params params;
	params.AllowedGait = AllowedGait;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.UpdateCharacterMovement
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::UpdateCharacterMovement()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.UpdateCharacterMovement");

	AALS_Base_CharacterBP_C_UpdateCharacterMovement_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SetMovementModel
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::SetMovementModel()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SetMovementModel");

	AALS_Base_CharacterBP_C_SetMovementModel_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SmoothCharacterRotation
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FRotator                Target                         (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
// float                          TargetInterpSpeed_Const_       (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          ActorInterpSpeed_Smooth_       (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::SmoothCharacterRotation(const struct FRotator& Target, float TargetInterpSpeed_Const_, float ActorInterpSpeed_Smooth_)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SmoothCharacterRotation");

	AALS_Base_CharacterBP_C_SmoothCharacterRotation_Params params;
	params.Target = Target;
	params.TargetInterpSpeed_Const_ = TargetInterpSpeed_Const_;
	params.ActorInterpSpeed_Smooth_ = ActorInterpSpeed_Smooth_;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.UpdateInAirRotation
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::UpdateInAirRotation()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.UpdateInAirRotation");

	AALS_Base_CharacterBP_C_UpdateInAirRotation_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.UpdateGroudedRotation
// (Public, HasDefaults, BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::UpdateGroudedRotation()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.UpdateGroudedRotation");

	AALS_Base_CharacterBP_C_UpdateGroudedRotation_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CacheValues
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::CacheValues()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.CacheValues");

	AALS_Base_CharacterBP_C_CacheValues_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SetEssentialValues
// (Public, BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::SetEssentialValues()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.SetEssentialValues");

	AALS_Base_CharacterBP_C_SetEssentialValues_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.PlayerMovementInput
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// bool                           IsForwardAxis                  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
void AALS_Base_CharacterBP_C::PlayerMovementInput(bool IsForwardAxis)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.PlayerMovementInput");

	AALS_Base_CharacterBP_C_PlayerMovementInput_Params params;
	params.IsForwardAxis = IsForwardAxis;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleTimeline__FinishedFunc
// (BlueprintEvent)
void AALS_Base_CharacterBP_C::MantleTimeline__FinishedFunc()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleTimeline__FinishedFunc");

	AALS_Base_CharacterBP_C_MantleTimeline__FinishedFunc_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleTimeline__UpdateFunc
// (BlueprintEvent)
void AALS_Base_CharacterBP_C::MantleTimeline__UpdateFunc()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.MantleTimeline__UpdateFunc");

	AALS_Base_CharacterBP_C_MantleTimeline__UpdateFunc_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_JumpAction_K2Node_InputActionEvent_13
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::InpActEvt_JumpAction_K2Node_InputActionEvent_13(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_JumpAction_K2Node_InputActionEvent_13");

	AALS_Base_CharacterBP_C_InpActEvt_JumpAction_K2Node_InputActionEvent_13_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_JumpAction_K2Node_InputActionEvent_12
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::InpActEvt_JumpAction_K2Node_InputActionEvent_12(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_JumpAction_K2Node_InputActionEvent_12");

	AALS_Base_CharacterBP_C_InpActEvt_JumpAction_K2Node_InputActionEvent_12_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_WalkAction_K2Node_InputActionEvent_11
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::InpActEvt_WalkAction_K2Node_InputActionEvent_11(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_WalkAction_K2Node_InputActionEvent_11");

	AALS_Base_CharacterBP_C_InpActEvt_WalkAction_K2Node_InputActionEvent_11_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_SelectRotationMode_1_K2Node_InputActionEvent_10
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::InpActEvt_SelectRotationMode_1_K2Node_InputActionEvent_10(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_SelectRotationMode_1_K2Node_InputActionEvent_10");

	AALS_Base_CharacterBP_C_InpActEvt_SelectRotationMode_1_K2Node_InputActionEvent_10_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_SelectRotationMode_2_K2Node_InputActionEvent_9
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::InpActEvt_SelectRotationMode_2_K2Node_InputActionEvent_9(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_SelectRotationMode_2_K2Node_InputActionEvent_9");

	AALS_Base_CharacterBP_C_InpActEvt_SelectRotationMode_2_K2Node_InputActionEvent_9_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_AimAction_K2Node_InputActionEvent_8
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::InpActEvt_AimAction_K2Node_InputActionEvent_8(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_AimAction_K2Node_InputActionEvent_8");

	AALS_Base_CharacterBP_C_InpActEvt_AimAction_K2Node_InputActionEvent_8_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_AimAction_K2Node_InputActionEvent_7
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::InpActEvt_AimAction_K2Node_InputActionEvent_7(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_AimAction_K2Node_InputActionEvent_7");

	AALS_Base_CharacterBP_C_InpActEvt_AimAction_K2Node_InputActionEvent_7_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_StanceAction_K2Node_InputActionEvent_6
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::InpActEvt_StanceAction_K2Node_InputActionEvent_6(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_StanceAction_K2Node_InputActionEvent_6");

	AALS_Base_CharacterBP_C_InpActEvt_StanceAction_K2Node_InputActionEvent_6_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_CameraAction_K2Node_InputActionEvent_5
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::InpActEvt_CameraAction_K2Node_InputActionEvent_5(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_CameraAction_K2Node_InputActionEvent_5");

	AALS_Base_CharacterBP_C_InpActEvt_CameraAction_K2Node_InputActionEvent_5_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_CameraAction_K2Node_InputActionEvent_4
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::InpActEvt_CameraAction_K2Node_InputActionEvent_4(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_CameraAction_K2Node_InputActionEvent_4");

	AALS_Base_CharacterBP_C_InpActEvt_CameraAction_K2Node_InputActionEvent_4_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_SprintAction_K2Node_InputActionEvent_3
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::InpActEvt_SprintAction_K2Node_InputActionEvent_3(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_SprintAction_K2Node_InputActionEvent_3");

	AALS_Base_CharacterBP_C_InpActEvt_SprintAction_K2Node_InputActionEvent_3_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_SprintAction_K2Node_InputActionEvent_2
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::InpActEvt_SprintAction_K2Node_InputActionEvent_2(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_SprintAction_K2Node_InputActionEvent_2");

	AALS_Base_CharacterBP_C_InpActEvt_SprintAction_K2Node_InputActionEvent_2_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_RagdollAction_K2Node_InputActionEvent_1
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::InpActEvt_RagdollAction_K2Node_InputActionEvent_1(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.InpActEvt_RagdollAction_K2Node_InputActionEvent_1");

	AALS_Base_CharacterBP_C_InpActEvt_RagdollAction_K2Node_InputActionEvent_1_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Backwards_K2Node_InputAxisEvent_1
// (BlueprintEvent)
// Parameters:
// float                          AxisValue                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::Backwards_K2Node_InputAxisEvent_1(float AxisValue)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Backwards_K2Node_InputAxisEvent_1");

	AALS_Base_CharacterBP_C_Backwards_K2Node_InputAxisEvent_1_Params params;
	params.AxisValue = AxisValue;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Left_K2Node_InputAxisEvent_2
// (BlueprintEvent)
// Parameters:
// float                          AxisValue                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::Left_K2Node_InputAxisEvent_2(float AxisValue)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Left_K2Node_InputAxisEvent_2");

	AALS_Base_CharacterBP_C_Left_K2Node_InputAxisEvent_2_Params params;
	params.AxisValue = AxisValue;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Down_K2Node_InputAxisEvent_3
// (BlueprintEvent)
// Parameters:
// float                          AxisValue                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::Down_K2Node_InputAxisEvent_3(float AxisValue)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Down_K2Node_InputAxisEvent_3");

	AALS_Base_CharacterBP_C_Down_K2Node_InputAxisEvent_3_Params params;
	params.AxisValue = AxisValue;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Right_K2Node_InputAxisEvent_4
// (BlueprintEvent)
// Parameters:
// float                          AxisValue                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::Right_K2Node_InputAxisEvent_4(float AxisValue)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Right_K2Node_InputAxisEvent_4");

	AALS_Base_CharacterBP_C_Right_K2Node_InputAxisEvent_4_Params params;
	params.AxisValue = AxisValue;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.ReceiveTick
// (Event, Public, BlueprintEvent)
// Parameters:
// float                          DeltaSeconds                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::ReceiveTick(float DeltaSeconds)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.ReceiveTick");

	AALS_Base_CharacterBP_C_ReceiveTick_Params params;
	params.DeltaSeconds = DeltaSeconds;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.ReceiveBeginPlay
// (Event, Protected, BlueprintEvent)
void AALS_Base_CharacterBP_C::ReceiveBeginPlay()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.ReceiveBeginPlay");

	AALS_Base_CharacterBP_C_ReceiveBeginPlay_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.K2_OnStartCrouch
// (Event, Public, BlueprintEvent)
// Parameters:
// float                          HalfHeightAdjust               (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          ScaledHalfHeightAdjust         (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::K2_OnStartCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.K2_OnStartCrouch");

	AALS_Base_CharacterBP_C_K2_OnStartCrouch_Params params;
	params.HalfHeightAdjust = HalfHeightAdjust;
	params.ScaledHalfHeightAdjust = ScaledHalfHeightAdjust;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.K2_OnEndCrouch
// (Event, Public, BlueprintEvent)
// Parameters:
// float                          HalfHeightAdjust               (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          ScaledHalfHeightAdjust         (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::K2_OnEndCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.K2_OnEndCrouch");

	AALS_Base_CharacterBP_C_K2_OnEndCrouch_Params params;
	params.HalfHeightAdjust = HalfHeightAdjust;
	params.ScaledHalfHeightAdjust = ScaledHalfHeightAdjust;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.K2_OnMovementModeChanged
// (Event, Public, BlueprintEvent)
// Parameters:
// TEnumAsByte<EMovementMode>     PrevMovementMode               (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EMovementMode>     NewMovementMode                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// unsigned char                  PrevCustomMode                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// unsigned char                  NewCustomMode                  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::K2_OnMovementModeChanged(TEnumAsByte<EMovementMode> PrevMovementMode, TEnumAsByte<EMovementMode> NewMovementMode, unsigned char PrevCustomMode, unsigned char NewCustomMode)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.K2_OnMovementModeChanged");

	AALS_Base_CharacterBP_C_K2_OnMovementModeChanged_Params params;
	params.PrevMovementMode = PrevMovementMode;
	params.NewMovementMode = NewMovementMode;
	params.PrevCustomMode = PrevCustomMode;
	params.NewCustomMode = NewCustomMode;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnJumped
// (Event, Public, BlueprintEvent)
void AALS_Base_CharacterBP_C::OnJumped()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnJumped");

	AALS_Base_CharacterBP_C_OnJumped_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnLanded
// (Event, Public, HasOutParms, BlueprintEvent)
// Parameters:
// struct FHitResult              hit                            (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm, IsPlainOldData, NoDestructor, ContainsInstancedReference)
void AALS_Base_CharacterBP_C::OnLanded(const struct FHitResult& hit)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.OnLanded");

	AALS_Base_CharacterBP_C_OnLanded_Params params;
	params.hit = hit;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Breakfall Event
// (BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::Breakfall_Event()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Breakfall Event");

	AALS_Base_CharacterBP_C_Breakfall_Event_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Roll Event
// (BlueprintCallable, BlueprintEvent)
void AALS_Base_CharacterBP_C::Roll_Event()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.Roll Event");

	AALS_Base_CharacterBP_C_Roll_Event_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_MovementState
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_MovementState> NewMovementState               (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::BPI_Set_MovementState(TEnumAsByte<EALS_MovementState> NewMovementState)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_MovementState");

	AALS_Base_CharacterBP_C_BPI_Set_MovementState_Params params;
	params.NewMovementState = NewMovementState;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_MovementAction
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_MovementAction> NewMovementAction              (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::BPI_Set_MovementAction(TEnumAsByte<EALS_MovementAction> NewMovementAction)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_MovementAction");

	AALS_Base_CharacterBP_C_BPI_Set_MovementAction_Params params;
	params.NewMovementAction = NewMovementAction;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_RotationMode
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_RotationMode> NewRotationMode                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::BPI_Set_RotationMode(TEnumAsByte<EALS_RotationMode> NewRotationMode)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_RotationMode");

	AALS_Base_CharacterBP_C_BPI_Set_RotationMode_Params params;
	params.NewRotationMode = NewRotationMode;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_Gait
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_Gait>         NewGait                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::BPI_Set_Gait(TEnumAsByte<EALS_Gait> NewGait)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_Gait");

	AALS_Base_CharacterBP_C_BPI_Set_Gait_Params params;
	params.NewGait = NewGait;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_ViewMode
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_ViewMode>     NewViewMode                    (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::BPI_Set_ViewMode(TEnumAsByte<EALS_ViewMode> NewViewMode)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_ViewMode");

	AALS_Base_CharacterBP_C_BPI_Set_ViewMode_Params params;
	params.NewViewMode = NewViewMode;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_OverlayState
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_OverlayState> NewOverlayState                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::BPI_Set_OverlayState(TEnumAsByte<EALS_OverlayState> NewOverlayState)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.BPI_Set_OverlayState");

	AALS_Base_CharacterBP_C_BPI_Set_OverlayState_Params params;
	params.NewOverlayState = NewOverlayState;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.ExecuteUbergraph_ALS_Base_CharacterBP
// (Final, HasDefaults)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_Base_CharacterBP_C::ExecuteUbergraph_ALS_Base_CharacterBP(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Base_CharacterBP.ALS_Base_CharacterBP_C.ExecuteUbergraph_ALS_Base_CharacterBP");

	AALS_Base_CharacterBP_C_ExecuteUbergraph_ALS_Base_CharacterBP_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
