#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// UserDefinedEnum ALS_Stance.ALS_Stance
enum class EALS_Stance : uint8_t
{
	ALS_Stance__NewEnumerator0     = 0,
	ALS_Stance__NewEnumerator1     = 1,
	ALS_Stance__ALS_MAX            = 2,

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
