// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.GetDebugTraceType
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// TEnumAsByte<EDrawDebugTrace>   ShowTraceType                  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EDrawDebugTrace>   DebugTypu                      (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_PlayerCameraManager_C::GetDebugTraceType(TEnumAsByte<EDrawDebugTrace> ShowTraceType, TEnumAsByte<EDrawDebugTrace>* DebugTypu)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.GetDebugTraceType");

	AALS_PlayerCameraManager_C_GetDebugTraceType_Params params;
	params.ShowTraceType = ShowTraceType;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (DebugTypu != nullptr)
		*DebugTypu = params.DebugTypu;

}


// Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.Get_CameraBehaviorParam
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FName                   CurveName                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
float AALS_PlayerCameraManager_C::Get_CameraBehaviorParam(const struct FName& CurveName)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.Get_CameraBehaviorParam");

	AALS_PlayerCameraManager_C_Get_CameraBehaviorParam_Params params;
	params.CurveName = CurveName;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.CalculateAxisIndependentLag
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent, BlueprintPure)
// Parameters:
// struct FVector                 CurrentLocation                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FVector                 TargetLocation                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FRotator                CameraRotation                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
// struct FVector                 LagSpeeds                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FVector                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
struct FVector AALS_PlayerCameraManager_C::CalculateAxisIndependentLag(const struct FVector& CurrentLocation, const struct FVector& TargetLocation, const struct FRotator& CameraRotation, const struct FVector& LagSpeeds)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.CalculateAxisIndependentLag");

	AALS_PlayerCameraManager_C_CalculateAxisIndependentLag_Params params;
	params.CurrentLocation = CurrentLocation;
	params.TargetLocation = TargetLocation;
	params.CameraRotation = CameraRotation;
	params.LagSpeeds = LagSpeeds;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;


	return params.ReturnValue;
}


// Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.CustomCameraBehavior
// (Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FVector                 Location                       (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FRotator                Rotation                       (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
// float                          FOV                            (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_PlayerCameraManager_C::CustomCameraBehavior(struct FVector* Location, struct FRotator* Rotation, float* FOV)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.CustomCameraBehavior");

	AALS_PlayerCameraManager_C_CustomCameraBehavior_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (Location != nullptr)
		*Location = params.Location;
	if (Rotation != nullptr)
		*Rotation = params.Rotation;
	if (FOV != nullptr)
		*FOV = params.FOV;

}


// Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.BlueprintUpdateCamera
// (BlueprintCosmetic, Event, Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
// class AActor*                  CameraTarget                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FVector                 NewCameraLocation              (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FRotator                NewCameraRotation              (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
// float                          NewCameraFOV                   (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor)
bool AALS_PlayerCameraManager_C::BlueprintUpdateCamera(class AActor* CameraTarget, struct FVector* NewCameraLocation, struct FRotator* NewCameraRotation, float* NewCameraFOV)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.BlueprintUpdateCamera");

	AALS_PlayerCameraManager_C_BlueprintUpdateCamera_Params params;
	params.CameraTarget = CameraTarget;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (NewCameraLocation != nullptr)
		*NewCameraLocation = params.NewCameraLocation;
	if (NewCameraRotation != nullptr)
		*NewCameraRotation = params.NewCameraRotation;
	if (NewCameraFOV != nullptr)
		*NewCameraFOV = params.NewCameraFOV;


	return params.ReturnValue;
}


// Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.OnPossess
// (BlueprintCallable, BlueprintEvent)
// Parameters:
// class APawn*                   NewPawn                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_PlayerCameraManager_C::OnPossess(class APawn* NewPawn)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.OnPossess");

	AALS_PlayerCameraManager_C_OnPossess_Params params;
	params.NewPawn = NewPawn;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.ExecuteUbergraph_ALS_PlayerCameraManager
// (Final)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_PlayerCameraManager_C::ExecuteUbergraph_ALS_PlayerCameraManager(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_PlayerCameraManager.ALS_PlayerCameraManager_C.ExecuteUbergraph_ALS_PlayerCameraManager");

	AALS_PlayerCameraManager_C_ExecuteUbergraph_ALS_PlayerCameraManager_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
