#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ALS_PlayerCameraBehavior.ALS_PlayerCameraBehavior_C.AnimGraph
struct UALS_PlayerCameraBehavior_C_AnimGraph_Params
{
	struct FPoseLink                                   AnimGraph;                                                 // (Parm, OutParm, NoDestructor)
};

// Function ALS_PlayerCameraBehavior.ALS_PlayerCameraBehavior_C.UpdateCharacterInfo
struct UALS_PlayerCameraBehavior_C_UpdateCharacterInfo_Params
{
};

// Function ALS_PlayerCameraBehavior.ALS_PlayerCameraBehavior_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ALS_PlayerCameraBehavior_AnimGraphNode_TransitionResult_C201AD03413A706ECFD533B5BE53C5AD
struct UALS_PlayerCameraBehavior_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ALS_PlayerCameraBehavior_AnimGraphNode_TransitionResult_C201AD03413A706ECFD533B5BE53C5AD_Params
{
};

// Function ALS_PlayerCameraBehavior.ALS_PlayerCameraBehavior_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ALS_PlayerCameraBehavior_AnimGraphNode_TransitionResult_12E957984E9E8E18C540A197CA5611D7
struct UALS_PlayerCameraBehavior_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ALS_PlayerCameraBehavior_AnimGraphNode_TransitionResult_12E957984E9E8E18C540A197CA5611D7_Params
{
};

// Function ALS_PlayerCameraBehavior.ALS_PlayerCameraBehavior_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ALS_PlayerCameraBehavior_AnimGraphNode_TransitionResult_0D30AFC6461B5834DDD33588DB08FD2B
struct UALS_PlayerCameraBehavior_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ALS_PlayerCameraBehavior_AnimGraphNode_TransitionResult_0D30AFC6461B5834DDD33588DB08FD2B_Params
{
};

// Function ALS_PlayerCameraBehavior.ALS_PlayerCameraBehavior_C.BlueprintUpdateAnimation
struct UALS_PlayerCameraBehavior_C_BlueprintUpdateAnimation_Params
{
	float                                              DeltaTimeX;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_PlayerCameraBehavior.ALS_PlayerCameraBehavior_C.ExecuteUbergraph_ALS_PlayerCameraBehavior
struct UALS_PlayerCameraBehavior_C_ExecuteUbergraph_ALS_PlayerCameraBehavior_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
