#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BPI_Interaction.BPI_Interaction_C
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UBPI_Interaction_C : public UInterface
{
public:


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass BPI_Interaction.BPI_Interaction_C");
		return ptr;
	}



	void fnInteract(class AActor* Reference_Actor);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
