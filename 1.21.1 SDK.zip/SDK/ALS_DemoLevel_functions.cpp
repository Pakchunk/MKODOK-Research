// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function ALS_DemoLevel.ALS_DemoLevel_C.InpActEvt_One_K2Node_InputKeyEvent_2
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_DemoLevel_C::InpActEvt_One_K2Node_InputKeyEvent_2(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_DemoLevel.ALS_DemoLevel_C.InpActEvt_One_K2Node_InputKeyEvent_2");

	AALS_DemoLevel_C_InpActEvt_One_K2Node_InputKeyEvent_2_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_DemoLevel.ALS_DemoLevel_C.InpActEvt_Escape_K2Node_InputKeyEvent_1
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void AALS_DemoLevel_C::InpActEvt_Escape_K2Node_InputKeyEvent_1(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_DemoLevel.ALS_DemoLevel_C.InpActEvt_Escape_K2Node_InputKeyEvent_1");

	AALS_DemoLevel_C_InpActEvt_Escape_K2Node_InputKeyEvent_1_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_DemoLevel.ALS_DemoLevel_C.ReceiveBeginPlay
// (Event, Protected, BlueprintEvent)
void AALS_DemoLevel_C::ReceiveBeginPlay()
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_DemoLevel.ALS_DemoLevel_C.ReceiveBeginPlay");

	AALS_DemoLevel_C_ReceiveBeginPlay_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_DemoLevel.ALS_DemoLevel_C.BndEvt__TriggerBox_1_K2Node_ActorBoundEvent_0_ActorBeginOverlapSignature__DelegateSignature
// (BlueprintEvent)
// Parameters:
// class AActor*                  OverlappedActor                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// class AActor*                  OtherActor                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_DemoLevel_C::BndEvt__TriggerBox_1_K2Node_ActorBoundEvent_0_ActorBeginOverlapSignature__DelegateSignature(class AActor* OverlappedActor, class AActor* OtherActor)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_DemoLevel.ALS_DemoLevel_C.BndEvt__TriggerBox_1_K2Node_ActorBoundEvent_0_ActorBeginOverlapSignature__DelegateSignature");

	AALS_DemoLevel_C_BndEvt__TriggerBox_1_K2Node_ActorBoundEvent_0_ActorBeginOverlapSignature__DelegateSignature_Params params;
	params.OverlappedActor = OverlappedActor;
	params.OtherActor = OtherActor;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_DemoLevel.ALS_DemoLevel_C.BndEvt__TriggerBox2_3_K2Node_ActorBoundEvent_3_ActorBeginOverlapSignature__DelegateSignature
// (BlueprintEvent)
// Parameters:
// class AActor*                  OverlappedActor                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// class AActor*                  OtherActor                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_DemoLevel_C::BndEvt__TriggerBox2_3_K2Node_ActorBoundEvent_3_ActorBeginOverlapSignature__DelegateSignature(class AActor* OverlappedActor, class AActor* OtherActor)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_DemoLevel.ALS_DemoLevel_C.BndEvt__TriggerBox2_3_K2Node_ActorBoundEvent_3_ActorBeginOverlapSignature__DelegateSignature");

	AALS_DemoLevel_C_BndEvt__TriggerBox2_3_K2Node_ActorBoundEvent_3_ActorBeginOverlapSignature__DelegateSignature_Params params;
	params.OverlappedActor = OverlappedActor;
	params.OtherActor = OtherActor;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_DemoLevel.ALS_DemoLevel_C.ExecuteUbergraph_ALS_DemoLevel
// (Final, HasDefaults)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void AALS_DemoLevel_C::ExecuteUbergraph_ALS_DemoLevel(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_DemoLevel.ALS_DemoLevel_C.ExecuteUbergraph_ALS_DemoLevel");

	AALS_DemoLevel_C_ExecuteUbergraph_ALS_DemoLevel_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
