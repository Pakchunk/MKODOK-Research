#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ALS_Player_Controller.ALS_Player_Controller_C.BPI_Get_DebugInfo
struct AALS_Player_Controller_C_BPI_Get_DebugInfo_Params
{
	class ACharacter*                                  DebugFocusCharacter;                                       // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                               DebugView;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                               ShowHUD;                                                   // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                               ShowTraces;                                                // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                               ShowDebugShapes;                                           // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                               ShowLayerColors;                                           // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                               Slomo;                                                     // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                               ShowCharacterInfo;                                         // (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Tab_K2Node_InputKeyEvent_9
struct AALS_Player_Controller_C_InpActEvt_Tab_K2Node_InputKeyEvent_9_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_T_K2Node_InputKeyEvent_8
struct AALS_Player_Controller_C_InpActEvt_T_K2Node_InputKeyEvent_8_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Y_K2Node_InputKeyEvent_7
struct AALS_Player_Controller_C_InpActEvt_Y_K2Node_InputKeyEvent_7_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_I_K2Node_InputKeyEvent_6
struct AALS_Player_Controller_C_InpActEvt_I_K2Node_InputKeyEvent_6_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Comma_K2Node_InputKeyEvent_5
struct AALS_Player_Controller_C_InpActEvt_Comma_K2Node_InputKeyEvent_5_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Period_K2Node_InputKeyEvent_4
struct AALS_Player_Controller_C_InpActEvt_Period_K2Node_InputKeyEvent_4_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_U_K2Node_InputKeyEvent_3
struct AALS_Player_Controller_C_InpActEvt_U_K2Node_InputKeyEvent_3_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_V_K2Node_InputKeyEvent_2
struct AALS_Player_Controller_C_InpActEvt_V_K2Node_InputKeyEvent_2_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_OpenOverlayMenu_K2Node_InputActionEvent_4
struct AALS_Player_Controller_C_InpActEvt_OpenOverlayMenu_K2Node_InputActionEvent_4_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_OpenOverlayMenu_K2Node_InputActionEvent_3
struct AALS_Player_Controller_C_InpActEvt_OpenOverlayMenu_K2Node_InputActionEvent_3_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_CycleOverlayUp_K2Node_InputActionEvent_2
struct AALS_Player_Controller_C_InpActEvt_CycleOverlayUp_K2Node_InputActionEvent_2_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_CycleOverlayDown_K2Node_InputActionEvent_1
struct AALS_Player_Controller_C_InpActEvt_CycleOverlayDown_K2Node_InputActionEvent_1_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.InpActEvt_Z_K2Node_InputKeyEvent_1
struct AALS_Player_Controller_C_InpActEvt_Z_K2Node_InputKeyEvent_1_Params
{
	struct FKey                                        Key;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.ReceivePossess
struct AALS_Player_Controller_C_ReceivePossess_Params
{
	class APawn*                                       PossessedPawn;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.ReceiveBeginPlay
struct AALS_Player_Controller_C_ReceiveBeginPlay_Params
{
};

// Function ALS_Player_Controller.ALS_Player_Controller_C.ExecuteUbergraph_ALS_Player_Controller
struct AALS_Player_Controller_C_ExecuteUbergraph_ALS_Player_Controller_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
