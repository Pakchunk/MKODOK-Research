// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_OverlayState
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_OverlayState> NewOverlayState                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UALS_Character_BPI_C::BPI_Set_OverlayState(TEnumAsByte<EALS_OverlayState> NewOverlayState)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_OverlayState");

	UALS_Character_BPI_C_BPI_Set_OverlayState_Params params;
	params.NewOverlayState = NewOverlayState;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_ViewMode
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_ViewMode>     NewViewMode                    (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UALS_Character_BPI_C::BPI_Set_ViewMode(TEnumAsByte<EALS_ViewMode> NewViewMode)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_ViewMode");

	UALS_Character_BPI_C_BPI_Set_ViewMode_Params params;
	params.NewViewMode = NewViewMode;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_Gait
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_Gait>         NewGait                        (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UALS_Character_BPI_C::BPI_Set_Gait(TEnumAsByte<EALS_Gait> NewGait)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_Gait");

	UALS_Character_BPI_C_BPI_Set_Gait_Params params;
	params.NewGait = NewGait;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_RotationMode
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_RotationMode> NewRotationMode                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UALS_Character_BPI_C::BPI_Set_RotationMode(TEnumAsByte<EALS_RotationMode> NewRotationMode)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_RotationMode");

	UALS_Character_BPI_C_BPI_Set_RotationMode_Params params;
	params.NewRotationMode = NewRotationMode;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_MovementAction
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_MovementAction> NewMovementAction              (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UALS_Character_BPI_C::BPI_Set_MovementAction(TEnumAsByte<EALS_MovementAction> NewMovementAction)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_MovementAction");

	UALS_Character_BPI_C_BPI_Set_MovementAction_Params params;
	params.NewMovementAction = NewMovementAction;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_MovementState
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EALS_MovementState> NewMovementState               (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UALS_Character_BPI_C::BPI_Set_MovementState(TEnumAsByte<EALS_MovementState> NewMovementState)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Set_MovementState");

	UALS_Character_BPI_C_BPI_Set_MovementState_Params params;
	params.NewMovementState = NewMovementState;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Get_EssentialValues
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FVector                 Velocity                       (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FVector                 Acceleration                   (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FVector                 MovementInput                  (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                           IsMoving                       (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                           HasMovementInput               (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
// float                          Speed                          (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          MovementInputAmount            (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FRotator                AimingRotation                 (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
// float                          AimYawRate                     (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UALS_Character_BPI_C::BPI_Get_EssentialValues(struct FVector* Velocity, struct FVector* Acceleration, struct FVector* MovementInput, bool* IsMoving, bool* HasMovementInput, float* Speed, float* MovementInputAmount, struct FRotator* AimingRotation, float* AimYawRate)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Get_EssentialValues");

	UALS_Character_BPI_C_BPI_Get_EssentialValues_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (Velocity != nullptr)
		*Velocity = params.Velocity;
	if (Acceleration != nullptr)
		*Acceleration = params.Acceleration;
	if (MovementInput != nullptr)
		*MovementInput = params.MovementInput;
	if (IsMoving != nullptr)
		*IsMoving = params.IsMoving;
	if (HasMovementInput != nullptr)
		*HasMovementInput = params.HasMovementInput;
	if (Speed != nullptr)
		*Speed = params.Speed;
	if (MovementInputAmount != nullptr)
		*MovementInputAmount = params.MovementInputAmount;
	if (AimingRotation != nullptr)
		*AimingRotation = params.AimingRotation;
	if (AimYawRate != nullptr)
		*AimYawRate = params.AimYawRate;

}


// Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Get_CurrentStates
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
// TEnumAsByte<EMovementMode>     PawnMovementMode               (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_MovementState> MovementState                  (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_MovementState> PrevMovementState              (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_MovementAction> MovementAction                 (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_RotationMode> RotationMode                   (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_Gait>         ActualGait                     (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_Stance>       ActualStance                   (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_ViewMode>     ViewMode                       (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TEnumAsByte<EALS_OverlayState> OverlayState                   (Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UALS_Character_BPI_C::BPI_Get_CurrentStates(TEnumAsByte<EMovementMode>* PawnMovementMode, TEnumAsByte<EALS_MovementState>* MovementState, TEnumAsByte<EALS_MovementState>* PrevMovementState, TEnumAsByte<EALS_MovementAction>* MovementAction, TEnumAsByte<EALS_RotationMode>* RotationMode, TEnumAsByte<EALS_Gait>* ActualGait, TEnumAsByte<EALS_Stance>* ActualStance, TEnumAsByte<EALS_ViewMode>* ViewMode, TEnumAsByte<EALS_OverlayState>* OverlayState)
{
	static auto fn = UObject::FindObject<UFunction>("Function ALS_Character_BPI.ALS_Character_BPI_C.BPI_Get_CurrentStates");

	UALS_Character_BPI_C_BPI_Get_CurrentStates_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

	if (PawnMovementMode != nullptr)
		*PawnMovementMode = params.PawnMovementMode;
	if (MovementState != nullptr)
		*MovementState = params.MovementState;
	if (PrevMovementState != nullptr)
		*PrevMovementState = params.PrevMovementState;
	if (MovementAction != nullptr)
		*MovementAction = params.MovementAction;
	if (RotationMode != nullptr)
		*RotationMode = params.RotationMode;
	if (ActualGait != nullptr)
		*ActualGait = params.ActualGait;
	if (ActualStance != nullptr)
		*ActualStance = params.ActualStance;
	if (ViewMode != nullptr)
		*ViewMode = params.ViewMode;
	if (OverlayState != nullptr)
		*OverlayState = params.OverlayState;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
