// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnPauseSong
// (Public, BlueprintCallable, BlueprintEvent)
void UBP_Comp_MusicPlayer_C::fnPauseSong()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnPauseSong");

	UBP_Comp_MusicPlayer_C_fnPauseSong_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnPlayPrevious
// (Public, BlueprintCallable, BlueprintEvent)
void UBP_Comp_MusicPlayer_C::fnPlayPrevious()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnPlayPrevious");

	UBP_Comp_MusicPlayer_C_fnPlayPrevious_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnPlayNext
// (Public, BlueprintCallable, BlueprintEvent)
void UBP_Comp_MusicPlayer_C::fnPlayNext()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnPlayNext");

	UBP_Comp_MusicPlayer_C_fnPlayNext_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnCreateHUD
// (Public, BlueprintCallable, BlueprintEvent)
void UBP_Comp_MusicPlayer_C::fnCreateHUD()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnCreateHUD");

	UBP_Comp_MusicPlayer_C_fnCreateHUD_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnPlaySong
// (Public, BlueprintCallable, BlueprintEvent)
void UBP_Comp_MusicPlayer_C::fnPlaySong()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.fnPlaySong");

	UBP_Comp_MusicPlayer_C_fnPlaySong_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.EventStartMusic
// (BlueprintCallable, BlueprintEvent)
void UBP_Comp_MusicPlayer_C::EventStartMusic()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.EventStartMusic");

	UBP_Comp_MusicPlayer_C_EventStartMusic_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.EventStopMusic
// (BlueprintCallable, BlueprintEvent)
void UBP_Comp_MusicPlayer_C::EventStopMusic()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.EventStopMusic");

	UBP_Comp_MusicPlayer_C_EventStopMusic_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.EventCheckMusicIsPlaying
// (BlueprintCallable, BlueprintEvent)
void UBP_Comp_MusicPlayer_C::EventCheckMusicIsPlaying()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.EventCheckMusicIsPlaying");

	UBP_Comp_MusicPlayer_C_EventCheckMusicIsPlaying_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.ExecuteUbergraph_BP_Comp_MusicPlayer
// (Final, HasDefaults)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void UBP_Comp_MusicPlayer_C::ExecuteUbergraph_BP_Comp_MusicPlayer(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Comp_MusicPlayer.BP_Comp_MusicPlayer_C.ExecuteUbergraph_BP_Comp_MusicPlayer");

	UBP_Comp_MusicPlayer_C_ExecuteUbergraph_BP_Comp_MusicPlayer_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
