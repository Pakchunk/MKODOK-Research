#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct ALS_ComponentAndTransform.ALS_ComponentAndTransform
// 0x0040 (old 0x0038)
struct FALS_ComponentAndTransform
{
	struct FTransform                                  Transform_8_5A922B8141278287C6E895A0DBC17B89;              // 0x0000(0x0030) (Edit, BlueprintVisible, IsPlainOldData, NoDestructor)
	class UPrimitiveComponent*                         Component_11_74DA46FC4578E87978977783DBA2F302;             // 0x0030(0x0008) (Edit, BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	unsigned char                                      UnknownData_manualfix2[0x8];
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
