#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function DEATH.DEATH_C.Construct
struct UDEATH_C_Construct_Params
{
};

// Function DEATH.DEATH_C.BndEvt__Button_301_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
struct UDEATH_C_BndEvt__Button_301_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature_Params
{
};

// Function DEATH.DEATH_C.ExecuteUbergraph_DEATH
struct UDEATH_C_ExecuteUbergraph_DEATH_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
