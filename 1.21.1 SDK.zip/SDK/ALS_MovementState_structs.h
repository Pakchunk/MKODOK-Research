#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// UserDefinedEnum ALS_MovementState.ALS_MovementState
enum class EALS_MovementState : uint8_t
{
	ALS_MovementState__NewEnumerator0 = 0,
	ALS_MovementState__NewEnumerator1 = 1,
	ALS_MovementState__NewEnumerator2 = 2,
	ALS_MovementState__NewEnumerator4 = 3,
	ALS_MovementState__NewEnumerator3 = 4,
	ALS_MovementState__ALS_MAX     = 5,

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
