#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass ALS_Camera_BPI.ALS_Camera_BPI_C
// 0x0000 (FullSize[0x0028] - InheritedSize[0x0028])
class UALS_Camera_BPI_C : public UInterface
{
public:


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass ALS_Camera_BPI.ALS_Camera_BPI_C");
		return ptr;
	}



	void BPI_Get_3P_TraceParams(struct FVector* TraceOrigin, float* TraceRadius, TEnumAsByte<ETraceTypeQuery>* TraceChannel);
	struct FTransform BPI_Get_3P_PivotTarget();
	struct FVector BPI_Get_FP_CameraTarget();
	void BPI_Get_CameraParameters(float* TP_FOV, float* FP_FOV, bool* RightShoulder);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
