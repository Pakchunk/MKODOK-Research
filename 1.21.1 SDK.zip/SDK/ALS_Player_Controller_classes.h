#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass ALS_Player_Controller.ALS_Player_Controller_C
// 0x003A (FullSize[0x05AA] - InheritedSize[0x0570])
class AALS_Player_Controller_C : public APlayerController
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                            // 0x0570(0x0008) (ZeroConstructor, Transient, DuplicateTransient)
	class ACharacter*                                  DebugFocusCharacter;                                       // 0x0578(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnTemplate, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	TArray<class ACharacter*>                          AvailableDebugCharacters;                                  // 0x0580(0x0010) (Edit, BlueprintVisible, DisableEditOnTemplate, DisableEditOnInstance, HasGetValueTypeHash)
	bool                                               ShowHUD;                                                   // 0x0590(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                               DebugView;                                                 // 0x0591(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                               ShowTraces;                                                // 0x0592(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                               ShowDebugShapes;                                           // 0x0593(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                               ShowLayerColors;                                           // 0x0594(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                               ShowCharacterInfo;                                         // 0x0595(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	unsigned char                                      UnknownData_NW82[0x2];                                     // 0x0596(0x0002) MISSED OFFSET (FIX SPACE BETWEEN PREVIOUS PROPERTY)
	class UALS_HUD_C*                                  ALS_HUD;                                                   // 0x0598(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UOverlayStateSwitcher_C*                     OverlaySwitcher;                                           // 0x05A0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                               OverlayMenuOpen;                                           // 0x05A8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                               Slomo;                                                     // 0x05A9(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)


	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass ALS_Player_Controller.ALS_Player_Controller_C");
		return ptr;
	}



	void BPI_Get_DebugInfo(class ACharacter** DebugFocusCharacter, bool* DebugView, bool* ShowHUD, bool* ShowTraces, bool* ShowDebugShapes, bool* ShowLayerColors, bool* Slomo, bool* ShowCharacterInfo);
	void InpActEvt_Tab_K2Node_InputKeyEvent_9(const struct FKey& Key);
	void InpActEvt_T_K2Node_InputKeyEvent_8(const struct FKey& Key);
	void InpActEvt_Y_K2Node_InputKeyEvent_7(const struct FKey& Key);
	void InpActEvt_I_K2Node_InputKeyEvent_6(const struct FKey& Key);
	void InpActEvt_Comma_K2Node_InputKeyEvent_5(const struct FKey& Key);
	void InpActEvt_Period_K2Node_InputKeyEvent_4(const struct FKey& Key);
	void InpActEvt_U_K2Node_InputKeyEvent_3(const struct FKey& Key);
	void InpActEvt_V_K2Node_InputKeyEvent_2(const struct FKey& Key);
	void InpActEvt_OpenOverlayMenu_K2Node_InputActionEvent_4(const struct FKey& Key);
	void InpActEvt_OpenOverlayMenu_K2Node_InputActionEvent_3(const struct FKey& Key);
	void InpActEvt_CycleOverlayUp_K2Node_InputActionEvent_2(const struct FKey& Key);
	void InpActEvt_CycleOverlayDown_K2Node_InputActionEvent_1(const struct FKey& Key);
	void InpActEvt_Z_K2Node_InputKeyEvent_1(const struct FKey& Key);
	void ReceivePossess(class APawn* PossessedPawn);
	void ReceiveBeginPlay();
	void ExecuteUbergraph_ALS_Player_Controller(int EntryPoint);
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
