// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function BP_Car_Base.BP_Car_Base_C.fnRemoveHUD
// (Public, BlueprintCallable, BlueprintEvent)
void ABP_Car_Base_C::fnRemoveHUD()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.fnRemoveHUD");

	ABP_Car_Base_C_fnRemoveHUD_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.fnRandomizeMaterial
// (Public, BlueprintCallable, BlueprintEvent)
void ABP_Car_Base_C::fnRandomizeMaterial()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.fnRandomizeMaterial");

	ABP_Car_Base_C_fnRandomizeMaterial_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.fnCreateHUD
// (Public, BlueprintCallable, BlueprintEvent)
void ABP_Car_Base_C::fnCreateHUD()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.fnCreateHUD");

	ABP_Car_Base_C_fnCreateHUD_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.Enable Incar View
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// bool                           State                          (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
void ABP_Car_Base_C::Enable_Incar_View(bool State)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.Enable Incar View");

	ABP_Car_Base_C_Enable_Incar_View_Params params;
	params.State = State;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.InpActEvt_E_K2Node_InputKeyEvent_1
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void ABP_Car_Base_C::InpActEvt_E_K2Node_InputKeyEvent_1(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.InpActEvt_E_K2Node_InputKeyEvent_1");

	ABP_Car_Base_C_InpActEvt_E_K2Node_InputKeyEvent_1_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.InpActEvt_Handbrake_K2Node_InputActionEvent_2
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void ABP_Car_Base_C::InpActEvt_Handbrake_K2Node_InputActionEvent_2(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.InpActEvt_Handbrake_K2Node_InputActionEvent_2");

	ABP_Car_Base_C_InpActEvt_Handbrake_K2Node_InputActionEvent_2_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.InpActEvt_Handbrake_K2Node_InputActionEvent_1
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm, HasGetValueTypeHash)
void ABP_Car_Base_C::InpActEvt_Handbrake_K2Node_InputActionEvent_1(const struct FKey& Key)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.InpActEvt_Handbrake_K2Node_InputActionEvent_1");

	ABP_Car_Base_C_InpActEvt_Handbrake_K2Node_InputActionEvent_1_Params params;
	params.Key = Key;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.EventCheckRendering
// (BlueprintCallable, BlueprintEvent)
void ABP_Car_Base_C::EventCheckRendering()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.EventCheckRendering");

	ABP_Car_Base_C_EventCheckRendering_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.ReceiveUnpossessed
// (Event, Public, BlueprintEvent)
// Parameters:
// class AController*             OldController                  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void ABP_Car_Base_C::ReceiveUnpossessed(class AController* OldController)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.ReceiveUnpossessed");

	ABP_Car_Base_C_ReceiveUnpossessed_Params params;
	params.OldController = OldController;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.fnInteract
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// class AActor*                  Reference_Actor                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void ABP_Car_Base_C::fnInteract(class AActor* Reference_Actor)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.fnInteract");

	ABP_Car_Base_C_fnInteract_Params params;
	params.Reference_Actor = Reference_Actor;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.Right_K2Node_InputAxisEvent_2
// (BlueprintEvent)
// Parameters:
// float                          AxisValue                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void ABP_Car_Base_C::Right_K2Node_InputAxisEvent_2(float AxisValue)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.Right_K2Node_InputAxisEvent_2");

	ABP_Car_Base_C_Right_K2Node_InputAxisEvent_2_Params params;
	params.AxisValue = AxisValue;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.Down_K2Node_InputAxisEvent_1
// (BlueprintEvent)
// Parameters:
// float                          AxisValue                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void ABP_Car_Base_C::Down_K2Node_InputAxisEvent_1(float AxisValue)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.Down_K2Node_InputAxisEvent_1");

	ABP_Car_Base_C_Down_K2Node_InputAxisEvent_1_Params params;
	params.AxisValue = AxisValue;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.ReceiveBeginPlay
// (Event, Protected, BlueprintEvent)
void ABP_Car_Base_C::ReceiveBeginPlay()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.ReceiveBeginPlay");

	ABP_Car_Base_C_ReceiveBeginPlay_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.ReceiveTick
// (Event, Public, BlueprintEvent)
// Parameters:
// float                          DeltaSeconds                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void ABP_Car_Base_C::ReceiveTick(float DeltaSeconds)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.ReceiveTick");

	ABP_Car_Base_C_ReceiveTick_Params params;
	params.DeltaSeconds = DeltaSeconds;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// (HasOutParms, BlueprintEvent)
// Parameters:
// class UPrimitiveComponent*     OverlappedComponent            (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// class AActor*                  OtherActor                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// class UPrimitiveComponent*     OtherComp                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// int                            OtherBodyIndex                 (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                           bFromSweep                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
// struct FHitResult              SweepResult                    (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm, IsPlainOldData, NoDestructor, ContainsInstancedReference)
void ABP_Car_Base_C::BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int OtherBodyIndex, bool bFromSweep, const struct FHitResult& SweepResult)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature");

	ABP_Car_Base_C_BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature_Params params;
	params.OverlappedComponent = OverlappedComponent;
	params.OtherActor = OtherActor;
	params.OtherComp = OtherComp;
	params.OtherBodyIndex = OtherBodyIndex;
	params.bFromSweep = bFromSweep;
	params.SweepResult = SweepResult;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_16
// (BlueprintEvent)
// Parameters:
// float                          AxisValue                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void ABP_Car_Base_C::InpAxisEvt_MoveRight_K2Node_InputAxisEvent_16(float AxisValue)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_16");

	ABP_Car_Base_C_InpAxisEvt_MoveRight_K2Node_InputAxisEvent_16_Params params;
	params.AxisValue = AxisValue;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_7
// (BlueprintEvent)
// Parameters:
// float                          AxisValue                      (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void ABP_Car_Base_C::InpAxisEvt_MoveForward_K2Node_InputAxisEvent_7(float AxisValue)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_7");

	ABP_Car_Base_C_InpAxisEvt_MoveForward_K2Node_InputAxisEvent_7_Params params;
	params.AxisValue = AxisValue;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.EventUpdateHUD
// (BlueprintCallable, BlueprintEvent)
void ABP_Car_Base_C::EventUpdateHUD()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.EventUpdateHUD");

	ABP_Car_Base_C_EventUpdateHUD_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function BP_Car_Base.BP_Car_Base_C.ExecuteUbergraph_BP_Car_Base
// (Final, HasDefaults)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void ABP_Car_Base_C::ExecuteUbergraph_BP_Car_Base(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_Car_Base.BP_Car_Base_C.ExecuteUbergraph_BP_Car_Base");

	ABP_Car_Base_C_ExecuteUbergraph_BP_Car_Base_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
