#pragma once

// Name: MKODOK, Version: 1.21.1


#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// UserDefinedEnum GroundedEntryState.GroundedEntryState
enum class EGroundedEntryState : uint8_t
{
	GroundedEntryState__NewEnumerator0 = 0,
	GroundedEntryState__NewEnumerator2 = 1,
	GroundedEntryState__GroundedEntryState_MAX = 2,

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
