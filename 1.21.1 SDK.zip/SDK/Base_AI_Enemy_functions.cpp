// Name: MKODOK, Version: 1.21.1

#include "../pch.h"

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

/*!!HELPER_DEF!!*/

/*!!DEFINE!!*/

namespace UFT
{
//---------------------------------------------------------------------------
// Functions
//---------------------------------------------------------------------------

// Function Base_AI_Enemy.Base_AI_Enemy_C.ReceiveBeginPlay
// (Event, Protected, BlueprintEvent)
void ABase_AI_Enemy_C::ReceiveBeginPlay()
{
	static auto fn = UObject::FindObject<UFunction>("Function Base_AI_Enemy.Base_AI_Enemy_C.ReceiveBeginPlay");

	ABase_AI_Enemy_C_ReceiveBeginPlay_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function Base_AI_Enemy.Base_AI_Enemy_C.ReceiveTick
// (Event, Public, BlueprintEvent)
// Parameters:
// float                          DeltaSeconds                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void ABase_AI_Enemy_C::ReceiveTick(float DeltaSeconds)
{
	static auto fn = UObject::FindObject<UFunction>("Function Base_AI_Enemy.Base_AI_Enemy_C.ReceiveTick");

	ABase_AI_Enemy_C_ReceiveTick_Params params;
	params.DeltaSeconds = DeltaSeconds;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function Base_AI_Enemy.Base_AI_Enemy_C.Attack
// (BlueprintCallable, BlueprintEvent)
void ABase_AI_Enemy_C::Attack()
{
	static auto fn = UObject::FindObject<UFunction>("Function Base_AI_Enemy.Base_AI_Enemy_C.Attack");

	ABase_AI_Enemy_C_Attack_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function Base_AI_Enemy.Base_AI_Enemy_C.AttackEnded
// (BlueprintCallable, BlueprintEvent)
void ABase_AI_Enemy_C::AttackEnded()
{
	static auto fn = UObject::FindObject<UFunction>("Function Base_AI_Enemy.Base_AI_Enemy_C.AttackEnded");

	ABase_AI_Enemy_C_AttackEnded_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function Base_AI_Enemy.Base_AI_Enemy_C.AttackNotify
// (BlueprintCallable, BlueprintEvent)
void ABase_AI_Enemy_C::AttackNotify()
{
	static auto fn = UObject::FindObject<UFunction>("Function Base_AI_Enemy.Base_AI_Enemy_C.AttackNotify");

	ABase_AI_Enemy_C_AttackNotify_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function Base_AI_Enemy.Base_AI_Enemy_C.AttackRefresh
// (BlueprintCallable, BlueprintEvent)
void ABase_AI_Enemy_C::AttackRefresh()
{
	static auto fn = UObject::FindObject<UFunction>("Function Base_AI_Enemy.Base_AI_Enemy_C.AttackRefresh");

	ABase_AI_Enemy_C_AttackRefresh_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function Base_AI_Enemy.Base_AI_Enemy_C.ReceiveAnyDamage
// (BlueprintAuthorityOnly, Event, Public, BlueprintEvent)
// Parameters:
// float                          Damage                         (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// class UDamageType*             DamageType                     (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// class AController*             InstigatedBy                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// class AActor*                  DamageCauser                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void ABase_AI_Enemy_C::ReceiveAnyDamage(float Damage, class UDamageType* DamageType, class AController* InstigatedBy, class AActor* DamageCauser)
{
	static auto fn = UObject::FindObject<UFunction>("Function Base_AI_Enemy.Base_AI_Enemy_C.ReceiveAnyDamage");

	ABase_AI_Enemy_C_ReceiveAnyDamage_Params params;
	params.Damage = Damage;
	params.DamageType = DamageType;
	params.InstigatedBy = InstigatedBy;
	params.DamageCauser = DamageCauser;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function Base_AI_Enemy.Base_AI_Enemy_C.DEATH
// (BlueprintCallable, BlueprintEvent)
void ABase_AI_Enemy_C::DEATH()
{
	static auto fn = UObject::FindObject<UFunction>("Function Base_AI_Enemy.Base_AI_Enemy_C.DEATH");

	ABase_AI_Enemy_C_DEATH_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function Base_AI_Enemy.Base_AI_Enemy_C.BndEvt__PawnSensing_K2Node_ComponentBoundEvent_0_SeePawnDelegate__DelegateSignature
// (BlueprintEvent)
// Parameters:
// class APawn*                   Pawn                           (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void ABase_AI_Enemy_C::BndEvt__PawnSensing_K2Node_ComponentBoundEvent_0_SeePawnDelegate__DelegateSignature(class APawn* Pawn)
{
	static auto fn = UObject::FindObject<UFunction>("Function Base_AI_Enemy.Base_AI_Enemy_C.BndEvt__PawnSensing_K2Node_ComponentBoundEvent_0_SeePawnDelegate__DelegateSignature");

	ABase_AI_Enemy_C_BndEvt__PawnSensing_K2Node_ComponentBoundEvent_0_SeePawnDelegate__DelegateSignature_Params params;
	params.Pawn = Pawn;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function Base_AI_Enemy.Base_AI_Enemy_C.BndEvt__PawnSensing_K2Node_ComponentBoundEvent_1_HearNoiseDelegate__DelegateSignature
// (HasOutParms, BlueprintEvent)
// Parameters:
// class APawn*                   Instigator                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FVector                 Location                       (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                          Volume                         (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void ABase_AI_Enemy_C::BndEvt__PawnSensing_K2Node_ComponentBoundEvent_1_HearNoiseDelegate__DelegateSignature(class APawn* Instigator, const struct FVector& Location, float Volume)
{
	static auto fn = UObject::FindObject<UFunction>("Function Base_AI_Enemy.Base_AI_Enemy_C.BndEvt__PawnSensing_K2Node_ComponentBoundEvent_1_HearNoiseDelegate__DelegateSignature");

	ABase_AI_Enemy_C_BndEvt__PawnSensing_K2Node_ComponentBoundEvent_1_HearNoiseDelegate__DelegateSignature_Params params;
	params.Instigator = Instigator;
	params.Location = Location;
	params.Volume = Volume;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function Base_AI_Enemy.Base_AI_Enemy_C.ExecuteUbergraph_Base_AI_Enemy
// (Final, HasDefaults)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
void ABase_AI_Enemy_C::ExecuteUbergraph_Base_AI_Enemy(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function Base_AI_Enemy.Base_AI_Enemy_C.ExecuteUbergraph_Base_AI_Enemy");

	ABase_AI_Enemy_C_ExecuteUbergraph_Base_AI_Enemy_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function Base_AI_Enemy.Base_AI_Enemy_C.ParentDeathEvent__DelegateSignature
// (Public, Delegate, BlueprintCallable, BlueprintEvent)
void ABase_AI_Enemy_C::ParentDeathEvent__DelegateSignature()
{
	static auto fn = UObject::FindObject<UFunction>("Function Base_AI_Enemy.Base_AI_Enemy_C.ParentDeathEvent__DelegateSignature");

	ABase_AI_Enemy_C_ParentDeathEvent__DelegateSignature_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


// Function Base_AI_Enemy.Base_AI_Enemy_C.ParentAttackEvent__DelegateSignature
// (Public, Delegate, BlueprintCallable, BlueprintEvent)
void ABase_AI_Enemy_C::ParentAttackEvent__DelegateSignature()
{
	static auto fn = UObject::FindObject<UFunction>("Function Base_AI_Enemy.Base_AI_Enemy_C.ParentAttackEvent__DelegateSignature");

	ABase_AI_Enemy_C_ParentAttackEvent__DelegateSignature_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);
	fn->FunctionFlags = flags;

}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
